#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
APP="Launchpad"
TITLE="启动台"
if [[ "${1:-}" != --skip-build ]]; then ./scripts/build.sh; fi
STAGE="$(mktemp -d "${TMPDIR:-/tmp}/desktop-dmg.XXXXXX")"
trap 'rm -rf "$STAGE"' EXIT
ditto "dist/$APP.app" "$STAGE/$APP.app"
ln -s /Applications "$STAGE/Applications"
printf '将应用拖到 Applications 文件夹即可安装。更新前请先退出旧版本。
' > "$STAGE/安装说明.txt"
if hdiutil create -volname "$TITLE" -srcfolder "$STAGE" -format UDZO -ov "dist/$APP.dmg"; then
  hdiutil verify "dist/$APP.dmg"
else
  hdiutil makehybrid -hfs -hfs-volume-name "$TITLE" -o "dist/$APP.dmg" "$STAGE"
fi
