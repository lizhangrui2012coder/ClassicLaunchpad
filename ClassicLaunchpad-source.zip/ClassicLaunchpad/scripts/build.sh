#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ "$(uname -s)" != Darwin ]]; then
  echo '需要在 macOS 上构建。' >&2
  exit 1
fi
xcrun --find swiftc >/dev/null
# 构建目录不放进源码包；签名在系统临时目录完成，避开云盘附加属性。
STAGE="$(mktemp -d "${TMPDIR:-/tmp}/mac-desktop-tools.XXXXXX")"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p build/module-cache dist
build_app() {
  local name="$1" title="$2" identifier="$3" version="$4" build="$5"
  shift 5
  local app="$STAGE/$name.app"
  mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources/zh-Hans.lproj"
  xcrun swiftc "Sources/$name/main.swift" -o "$app/Contents/MacOS/$name" \
    -module-cache-path "$ROOT/build/module-cache" "$@"
  cat > "$app/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>$name</string>
<key>CFBundleIdentifier</key><string>$identifier</string>
<key>CFBundleName</key><string>$title</string>
<key>CFBundleDisplayName</key><string>$title</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>$version</string>
<key>CFBundleVersion</key><string>$build</string>
<key>LSMinimumSystemVersion</key><string>13.0</string>
<key>LSUIElement</key><false/>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST
  printf '"CFBundleDisplayName" = "%s";\n"CFBundleName" = "%s";\n' "$title" "$title" > "$app/Contents/Resources/zh-Hans.lproj/InfoPlist.strings"
  local iconset="$STAGE/AppIcon.iconset"
  mkdir -p "$iconset"
  for size in 16 32 128 256 512; do
    sips -z "$size" "$size" Resources/AppIcon.png --out "$iconset/icon_${size}x${size}.png" >/dev/null
    local double=$((size * 2))
    sips -z "$double" "$double" Resources/AppIcon.png --out "$iconset/icon_${size}x${size}@2x.png" >/dev/null
  done
  python3 - "$iconset" "$app/Contents/Resources/AppIcon.icns" <<'PYICON'
import sys,struct
from pathlib import Path
root=Path(sys.argv[1]); chunks=[]
for code,file in [('icp4','icon_16x16.png'),('icp5','icon_32x32.png'),('ic07','icon_128x128.png'),('ic08','icon_256x256.png'),('ic09','icon_512x512.png'),('ic10','icon_512x512@2x.png')]:
 data=(root/file).read_bytes();chunks.append(code.encode()+struct.pack('>I',len(data)+8)+data)
body=b''.join(chunks);Path(sys.argv[2]).write_bytes(b'icns'+struct.pack('>I',len(body)+8)+body)
PYICON
  /usr/libexec/PlistBuddy -c 'Add :CFBundleIconFile string AppIcon' "$app/Contents/Info.plist"
  codesign --force --deep --sign - "$app"
  ditto "$app" "dist/$name.app"
  echo "已构建 dist/$name.app"
}
build_app Launchpad 启动台 local.classiclaunchpad 0.8.2 82 -framework Cocoa -framework QuartzCore -framework CoreImage -lsqlite3
if [[ "${1:-}" == --test ]]; then
  dist/Launchpad.app/Contents/MacOS/Launchpad --self-test
fi
