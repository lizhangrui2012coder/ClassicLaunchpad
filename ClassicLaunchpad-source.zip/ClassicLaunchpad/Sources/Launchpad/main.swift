import Cocoa
import QuartzCore
import CoreImage
import Darwin
import SQLite3

struct WallpaperChoice {
 var provider:String
 var assetID:String?
 var imageURL:URL?
}
struct WallpaperFile {
 var url:URL
 var fingerprint:String
 var kind:String
}
struct WallpaperCacheCandidate {
 let url:URL;let width:Int;let height:Int;let modified:Date
}
final class SystemWallpaper {
 static let shared=SystemWallpaper()
 let home=FileManager.default.homeDirectoryForCurrentUser
 var storeURL:URL {home.appendingPathComponent("Library/Application Support/com.apple.wallpaper/Store/Index.plist")}
 var cacheRoot:URL {home.appendingPathComponent("Library/Containers/com.apple.wallpaper.agent/Data/Library/Caches/com.apple.wallpaper.caches")}
 func dictionary(at url:URL)->[String:Any]? {
 guard let data=try? Data(contentsOf:url) else{return nil}
 return (try? PropertyListSerialization.propertyList(from:data,format:nil)) as? [String:Any]
 }
 static func selectedNode(_ store:[String:Any],display:String?,space:String?)->[String:Any]? {
 if let all=store["AllSpacesAndDisplays"] as? [String:Any],!all.isEmpty {return all}
 if let space,let spaces=store["Spaces"] as? [String:Any],let selected=spaces[space] as? [String:Any] {
 if let display,let displays=selected["Displays"] as? [String:Any],let node=displays[display] as? [String:Any] {return node}
 if let node=selected["Default"] as? [String:Any] {return node}
 }
 if let display,let displays=store["Displays"] as? [String:Any],let node=displays[display] as? [String:Any] {return node}
 if let spaces=store["Spaces"] as? [String:Any],let base=spaces[""] as? [String:Any] {
 if let display,let displays=base["Displays"] as? [String:Any],let node=displays[display] as? [String:Any] {return node}
 if let node=base["Default"] as? [String:Any] {return node}
 }
 return store["SystemDefault"] as? [String:Any]
 }
 static func imageURL(in value:Any,depth:Int=0)->URL? {
 guard depth<5 else{return nil}
 if let text=value as? String {
 if let url=URL(string:text),url.isFileURL {return url}
 if text.hasPrefix("/") {return URL(fileURLWithPath:text)}
 }
 if let data=value as? Data,let decoded=try? PropertyListSerialization.propertyList(from:data,format:nil) {return imageURL(in:decoded,depth:depth+1)}
 if let values=value as? [String:Any] {
 for key in ["url","URL","fileURL","imageURL","path","Files","files"] {if let v=values[key],let url=imageURL(in:v,depth:depth+1) {return url}}
 }
 if let values=value as? [Any] {for v in values {if let url=imageURL(in:v,depth:depth+1) {return url}}}
 return nil
 }
 static func choice(in node:[String:Any])->WallpaperChoice? {
 // Desktop and Linked contain wallpaper; Idle contains the screen saver and is excluded.
 for key in ["Desktop","Linked"] {
 guard let desktop=node[key] as? [String:Any],let content=desktop["Content"] as? [String:Any],let choices=content["Choices"] as? [[String:Any]],let first=choices.first,let provider=first["Provider"] as? String else {continue}
 var config:[String:Any]=[:]
 if let data=first["Configuration"] as? Data,let decoded=(try? PropertyListSerialization.propertyList(from:data,format:nil)) as? [String:Any] {config=decoded}
 else if let decoded=first["Configuration"] as? [String:Any] {config=decoded}
 return WallpaperChoice(provider:provider,assetID:config["assetID"] as? String,imageURL:imageURL(in:config) ?? first["Files"].flatMap {imageURL(in:$0)})
 }
 return nil
 }
 func currentSpace(display:String?,isMain:Bool)->String? {
 guard let prefs=dictionary(at:home.appendingPathComponent("Library/Preferences/com.apple.spaces.plist")),let configuration=prefs["SpacesDisplayConfiguration"] as? [String:Any],let management=configuration["Management Data"] as? [String:Any],let monitors=management["Monitors"] as? [[String:Any]] else{return nil}
 let monitor=monitors.first { ($0["Display Identifier"] as? String)==display } ?? (isMain ? monitors.first {($0["Display Identifier"] as? String)=="Main"}:nil)
 return (monitor?["Current Space"] as? [String:Any])?["uuid"] as? String
 }
 func shuffleSelection()->(id:String,modified:Date)? {
 let path=home.appendingPathComponent("Library/Containers/com.apple.wallpaper.extension.aerials/Data/Library/Application Support/Shuffle/ShuffleOrder.db").path
 var database:OpaquePointer?
 guard sqlite3_open_v2(path,&database,SQLITE_OPEN_READONLY|SQLITE_OPEN_NOMUTEX,nil)==SQLITE_OK,let database else {if let database {sqlite3_close(database)};return nil}
 defer {sqlite3_close(database)}
 var statement:OpaquePointer?
 guard sqlite3_prepare_v2(database,"SELECT ZCURRENTID,ZDATEMODIFIED FROM ZPERSISTENTSHUFFLEORDER ORDER BY ZDATEMODIFIED DESC LIMIT 1",-1,&statement,nil)==SQLITE_OK,let statement else{return nil}
 defer {sqlite3_finalize(statement)}
 guard sqlite3_step(statement)==SQLITE_ROW,let text=sqlite3_column_text(statement,0) else{return nil}
 let id=String(cString:text)
 guard UUID(uuidString:id) != nil else{return nil}
 return (id,Date(timeIntervalSinceReferenceDate:sqlite3_column_double(statement,1)))
 }
 static func bestCache(_ candidates:[WallpaperCacheCandidate],width:Int,height:Int)->WallpaperCacheCandidate? {
 let exact=candidates.filter {$0.width==width && $0.height==height}
 // Never borrow another display's differently cropped image.
 return exact.max {$0.modified<$1.modified}
 }
 func cachedImage(provider:String,width:Int,height:Int)->WallpaperCacheCandidate? {
 let suffix=provider.replacingOccurrences(of:"com.apple.wallpaper.choice.",with:"")
 let folder=cacheRoot.appendingPathComponent("extension-com.apple.wallpaper.extension."+suffix)
 guard let files=try? FileManager.default.contentsOfDirectory(at:folder,includingPropertiesForKeys:[.contentModificationDateKey],options:[.skipsHiddenFiles]) else{return nil}
 let candidates:[WallpaperCacheCandidate]=files.compactMap {url in
 guard url.pathExtension.lowercased()=="bmp" else{return nil}
 let parts=url.deletingPathExtension().lastPathComponent.split(separator:"-")
 guard parts.count>=5,let w=Int(parts[1]),let h=Int(parts[2]),let values=try? url.resourceValues(forKeys:[.contentModificationDateKey]) else{return nil}
 return WallpaperCacheCandidate(url:url,width:w,height:h,modified:values.contentModificationDate ?? .distantPast)
 }
 return Self.bestCache(candidates,width:width,height:height)
 }
 func file(display:String?,space:String?,width:Int,height:Int,legacy:URL?)->WallpaperFile? {
 var selected:WallpaperChoice?
 if let store=dictionary(at:storeURL),let node=Self.selectedNode(store,display:display,space:space) {selected=Self.choice(in:node)}
 if let selected {
 if selected.provider.hasSuffix(".image"),let url=selected.imageURL,FileManager.default.fileExists(atPath:url.path) {
 return makeFile(url,kind:"系统当前图片",selection:selected.provider)
 }
 let shuffle=selected.provider.hasSuffix(".aerials") ? shuffleSelection():nil
 let selection=selected.provider+"|"+(selected.assetID ?? "")+"|"+(shuffle?.id ?? "")
 if let cache=cachedImage(provider:selected.provider,width:width,height:height) {
 return makeFile(cache.url,kind:"系统当前壁纸缓存",selection:selection)
 }
 if let url=selected.imageURL,FileManager.default.fileExists(atPath:url.path) {return makeFile(url,kind:"系统当前图片",selection:selection)}
 if selected.provider.hasSuffix(".aerials"),let asset=shuffle?.id ?? selected.assetID {
 for root in [home.appendingPathComponent("Library/Application Support/com.apple.wallpaper/aerials/thumbnails"),URL(fileURLWithPath:"/Library/Application Support/com.apple.idleassetsd/Customer/snapshots")] {
 let thumbnail=root.appendingPathComponent(asset+".png")
 if FileManager.default.fileExists(atPath:thumbnail.path) {return makeFile(thumbnail,kind:"当前航拍壁纸预览",selection:selection)}
 }
 }
 // A recognized dynamic provider must not silently fall back to an unrelated legacy desktop.
 if selected.provider.hasSuffix(".aerials") {return nil}
 }
 if let legacy {return makeFile(legacy,kind:"系统图片接口",selection:"")}
 return nil
 }
 func makeFile(_ url:URL,kind:String,selection:String)->WallpaperFile {
 let modified=(try? url.resourceValues(forKeys:[.contentModificationDateKey]).contentModificationDate)?.timeIntervalSince1970 ?? 0
 return WallpaperFile(url:url,fingerprint:selection+"|"+url.path+"|"+String(modified),kind:kind)
 }
 func file(for screen:NSScreen)->WallpaperFile? {
 let id=(screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber)?.uint32Value ?? CGMainDisplayID()
 let display=CGDisplayCreateUUIDFromDisplayID(id).map {CFUUIDCreateString(nil,$0.takeRetainedValue()) as String}
 let space=currentSpace(display:display,isMain:id==CGMainDisplayID())
 return file(display:display,space:space,width:Int((screen.frame.width*screen.backingScaleFactor).rounded()),height:Int((screen.frame.height*screen.backingScaleFactor).rounded()),legacy:NSWorkspace.shared.desktopImageURL(for:screen))
 }
}

func chineseAppName(url:URL,bundle:Bundle?)->String {
 let languages=["zh_CN","zh-Hans","zh-Hans_CN","zh"]
 if let resources=bundle?.resourceURL {
 let table=resources.appendingPathComponent("InfoPlist.loctable")
 if let data=try? Data(contentsOf:table),let all=(try? PropertyListSerialization.propertyList(from:data,format:nil)) as? [String:Any] {
 for lang in languages {if let strings=all[lang] as? [String:Any],let name=(strings["CFBundleDisplayName"] ?? strings["CFBundleName"]) as? String,!name.isEmpty {return name}}
 }
 for lang in languages {
 let file=resources.appendingPathComponent(lang+".lproj/InfoPlist.strings")
 if let data=try? Data(contentsOf:file),let strings=(try? PropertyListSerialization.propertyList(from:data,format:nil)) as? [String:Any],let name=(strings["CFBundleDisplayName"] ?? strings["CFBundleName"]) as? String,!name.isEmpty {return name}
 }
 }
 return (bundle?.localizedInfoDictionary?["CFBundleDisplayName"] as? String) ?? (bundle?.localizedInfoDictionary?["CFBundleName"] as? String) ?? (bundle?.object(forInfoDictionaryKey:"CFBundleDisplayName") as? String) ?? url.deletingPathExtension().lastPathComponent
}
struct AppItem { let path: String; let name: String; let icon: NSImage }
struct Tile: Codable { var id = UUID().uuidString; var name: String; var paths: [String] }
struct Layout: Codable {
 var tiles: [Tile] = []; var hidden: [String] = []; var columns = 7; var rows = 5; var iconSize: Double = 76; var blur = true
 var freeLayout:Bool?=false
 var slots:[String:Int]?=nil
 var followWallpaper:Bool?=true
}
final class Store {
 var apps: [String: AppItem] = [:]
 var layout = Layout()
 let file: URL
 var testing = false
 init(test: Bool = false) {
 let base = FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0].appendingPathComponent("ClassicLaunchpad")
 file = base.appendingPathComponent("layout.json");testing=test
 if !test, let data = try? Data(contentsOf:file), let saved = try? JSONDecoder().decode(Layout.self,from:data) { layout = saved }
 scan()
 }
 func scan() {
 apps.removeAll()
 for root in ["/Applications", "/System/Applications", NSHomeDirectory()+"/Applications"] {
 guard let walker = FileManager.default.enumerator(at:URL(fileURLWithPath:root),includingPropertiesForKeys:nil,options:[.skipsHiddenFiles]) else {continue}
 for case let url as URL in walker where url.pathExtension == "app" {
 walker.skipDescendants()
 if url.lastPathComponent == "ClassicLaunchpad.app" {continue}
 let bundle = Bundle(url:url)
 let name=chineseAppName(url:url,bundle:bundle)
 apps[url.path] = AppItem(path:url.path,name:name,icon:testing ? NSImage(size:NSSize(width:128,height:128)):NSWorkspace.shared.icon(forFile:url.path))
 }
 }
 layout.tiles = layout.tiles.compactMap { t in var t=t;t.paths=t.paths.filter {apps[$0] != nil};return t.paths.isEmpty ? nil : t }
 let known = Set(layout.tiles.flatMap(\.paths)+layout.hidden)
 for a in apps.values.sorted(by:{$0.name.localizedStandardCompare($1.name) == .orderedAscending}) where !known.contains(a.path) {layout.tiles.append(Tile(name:a.name,paths:[a.path]))}
 }
 func save() {if testing {return};layout.syncSlots();for i in layout.tiles.indices where layout.tiles[i].paths.count==1 {if let a=apps[layout.tiles[i].paths[0]] {layout.tiles[i].name=a.name}};try? FileManager.default.createDirectory(at:file.deletingLastPathComponent(),withIntermediateDirectories:true);if let d=try? JSONEncoder().encode(layout) {try? d.write(to:file,options:.atomic)}}
 func results(_ query:String) -> [Tile] {
 if query.isEmpty {return layout.tiles}
 let q=query.folding(options:[.diacriticInsensitive,.caseInsensitive],locale:.current)
 return layout.tiles.flatMap(\.paths).compactMap {apps[$0]}.filter { a in
 let n=a.name.folding(options:[.diacriticInsensitive,.caseInsensitive],locale:.current)
 let initials=n.split(whereSeparator:{$0 == " " || $0 == "-"}).compactMap(\.first).map(String.init).joined()
 return n.contains(q) || initials.hasPrefix(q) || URL(fileURLWithPath:a.path).deletingPathExtension().lastPathComponent.localizedCaseInsensitiveContains(query)
 }.map {Tile(id:$0.path,name:$0.name,paths:[$0.path])}
 }
}
// Mutations preserve app membership and stable tile identifiers.
extension Layout {
 mutating func syncSlots(){
 var map=slots ?? [:];let ids=Set(tiles.map(\.id));map=map.filter {ids.contains($0.key) && $0.value>=0}
 var used=Set<Int>()
 for t in tiles {if let slot=map[t.id],used.insert(slot).inserted {continue};var slot=0;while used.contains(slot) {slot+=1};map[t.id]=slot;used.insert(slot)}
 slots=map
 }
 mutating func moveFree(_ source:Tile,from folder:String?,to slot:Int,group target:String?){
 syncSlots();let old=slots?[source.id]
 if let target,target != source.id {place(source,from:folder,target:target,group:true,index:tiles.count);slots?.removeValue(forKey:source.id);syncSlots();return}
 if folder != nil {place(source,from:folder,target:nil,group:false,index:tiles.count)}
 let displaced=tiles.first {t in t.id != source.id && slots?[t.id]==slot}
 if let displaced {
 if let old {slots?[displaced.id]=old} else {var vacancy=0;let occupied=Set((slots ?? [:]).values);while occupied.contains(vacancy) || vacancy==slot {vacancy+=1};slots?[displaced.id]=vacancy}
 }
 slots?[source.id]=max(0,slot);syncSlots()
 }
 mutating func tidy() {
 tiles = tiles.compactMap { tile in
 var t=tile
 var seen=Set<String>();t.paths=t.paths.filter {seen.insert($0).inserted}
 return t.paths.isEmpty ? nil:t
 }
 }
 mutating func place(_ source:Tile,from folder:String?,target:String?,group:Bool,index:Int) {
 if folder==nil,target==source.id {return}
 if let folder,let i=tiles.firstIndex(where:{$0.id==folder}) {
 guard let path=source.paths.first,tiles[i].paths.contains(path) else{return}
 tiles[i].paths.removeAll {$0==path}
 } else {
 guard let i=tiles.firstIndex(where:{$0.id==source.id}) else{return}
 tiles.remove(at:i)
 }
 if group,let target,let i=tiles.firstIndex(where:{$0.id==target}) {
 let wasFolder=tiles[i].paths.count>1
 tiles[i].paths += source.paths
 if !wasFolder {tiles[i].name="文件夹"}
 } else {
 let destination=target.flatMap {id in tiles.firstIndex(where:{$0.id==id})} ?? min(max(0,index),tiles.count)
 tiles.insert(source,at:destination)
 }
 tidy()
 }
 mutating func reorderInFolder(_ id:String,path:String,before:String?) {
 guard let i=tiles.firstIndex(where:{$0.id==id}),let from=tiles[i].paths.firstIndex(of:path),path != before else{return}
 tiles[i].paths.remove(at:from)
 let to=before.flatMap {tiles[i].paths.firstIndex(of:$0)} ?? tiles[i].paths.count
 tiles[i].paths.insert(path,at:to)
 }
}
struct PageSwipe {
 var active=false;var fired=false;var total:Double=0;var last:Double = -.infinity;var contactBased=false
 mutating func reset(){active=false;fired=false;total=0;last = -.infinity;contactBased=false}
 mutating func contactBegan(){contactBased=true;active=true;fired=false;total=0}
 mutating func feed(x:Double,y:Double,precise:Bool,begin:Bool,end:Bool,cancel:Bool,momentum:Bool,phased:Bool,time:Double)->Int? {
 if momentum {return nil}
 if cancel {active=false;return nil}
 if !contactBased {
 // A changed/end event never rearms a phased gesture.
 if begin || (!phased && time-last>0.75) {active=true;fired=false;total=0}
 }
 last=time
 defer {if end {active=false}}
 guard active,!fired else{return nil}
 if precise {
 guard abs(x)>abs(y)*1.2,abs(x)>0.05 else{return nil}
 total+=x
 } else {total += abs(x)>abs(y) ? x:y}
 let threshold=precise ? 40.0:2.0
 guard abs(total)>=threshold else{return nil}
 fired=true;return total<0 ? 1:-1
 }
}
// A held icon turns one page after a dwell; leave the edge to rearm.
struct DragPageEdge {
 var direction=0;var entered:Double=0;var fired=false
 mutating func reset(){direction=0;entered=0;fired=false}
 mutating func update(x:Double,y:Double,width:Double,height:Double,time:Double)->Int? {
 let zone=max(64,min(110,width*0.045))
 let valid=y>=0 && y<=height && x>=(-zone) && x<=width+zone
 let next=valid ? (x<zone ? -1:x>width-zone ? 1:0):0
 if next != direction {direction=next;entered=time;fired=false}
 guard next != 0,!fired,time-entered>=0.48 else{return nil}
 fired=true;return next
 }
}
// Activation is delivered exactly once, after both the overlay and app are ready.
struct LaunchHandoff {
 var overlayGone=false;var appReady=false;var delivered=false
 mutating func ready()->Bool {appReady=true;return take()}
 mutating func hidden()->Bool {overlayGone=true;return take()}
 private mutating func take()->Bool {guard overlayGone,appReady,!delivered else{return false};delivered=true;return true}
}
struct TileDrag:Codable {var tile:Tile;var folder:String?}
extension NSPasteboard.PasteboardType {static let launcherTile=NSPasteboard.PasteboardType("local.classiclaunchpad.tile")}
final class PadWindow: NSWindow {
 override var canBecomeKey:Bool {true}
 override var canBecomeMain:Bool {true}
 var escape:(()->Void)?
 override func cancelOperation(_ sender:Any?) {escape?()}
}
final class TileButton: NSButton,NSDraggingSource {
 var tile:Tile!;weak var pad:PadView?
 override func hitTest(_ point:NSPoint)->NSView? {bounds.contains(convert(point,from:superview)) ? self:nil}
 override func mouseDown(with event:NSEvent) {
 let start=event.locationInWindow
 let press=CABasicAnimation(keyPath:"transform.scale");press.fromValue=1;press.toValue=0.94;press.duration=0.07;press.fillMode = .forwards;press.isRemovedOnCompletion=false;layer?.add(press,forKey:"press")
 defer {layer?.removeAnimation(forKey:"press")}
 while let next=window?.nextEvent(matching:[.leftMouseDragged,.leftMouseUp]) {
 if next.type == .leftMouseUp {pad?.activate(tile);return}
 if hypot(next.locationInWindow.x-start.x,next.locationInWindow.y-start.y)>7 {
 guard let pad,let data=try? JSONEncoder().encode(TileDrag(tile:tile,folder:pad.folderID)) else{return}
 layer?.removeAnimation(forKey:"press")
 let pasteboard=NSPasteboardItem();pasteboard.setData(data,forType:.launcherTile)
 let item=NSDraggingItem(pasteboardWriter:pasteboard)
 let size=min(pad.store.layout.iconSize*1.12,bounds.width-10)
 item.setDraggingFrame(NSRect(x:bounds.midX-size/2,y:bounds.midY-size/2,width:size,height:size),contents:pad.icon(tile))
 pad.beginTileDrag(id:tile.id,source:self);alphaValue=0.12
 let session=beginDraggingSession(with:[item],event:next,source:self);session.animatesToStartingPositionsOnCancelOrFail=true
 return
 }
 }
 }
 func draggingSession(_ session:NSDraggingSession,sourceOperationMaskFor context:NSDraggingContext)->NSDragOperation {.move}
 func ignoreModifierKeys(for session:NSDraggingSession)->Bool {true}
 func draggingSession(_ session:NSDraggingSession,movedTo screenPoint:NSPoint) {pad?.trackDraggingPointer(screenPoint)}
 func draggingSession(_ session:NSDraggingSession,endedAt screenPoint:NSPoint,operation:NSDragOperation) {alphaValue=1;pad?.endTileDrag();pad?.retainedDragSource=nil}
 override func rightMouseDown(with event:NSEvent) {
 guard let pad else{return}
 let menu=NSMenu()
 let open=NSMenuItem(title:tile.paths.count>1 ? "打开文件夹":"打开",action:#selector(PadView.menuOpen(_:)),keyEquivalent:"");open.target=pad;open.representedObject=tile.id;menu.addItem(open)
 if pad.folderID != nil {
 let extract=NSMenuItem(title:"移出文件夹",action:#selector(PadView.extractTile(_:)),keyEquivalent:"");extract.target=pad;extract.representedObject=tile.paths.first;menu.addItem(extract)
 } else {
 let hide=NSMenuItem(title:"隐藏",action:#selector(PadView.hideTile(_:)),keyEquivalent:"");hide.target=pad;hide.representedObject=tile.id;menu.addItem(hide)
 if tile.paths.count>1 {let item=NSMenuItem(title:"解散文件夹",action:#selector(PadView.ungroup(_:)),keyEquivalent:"");item.target=pad;item.representedObject=tile.id;menu.addItem(item)}
 }
 NSMenu.popUpContextMenu(menu,with:event,for:self)
 }
}
final class Canvas:NSView {
 override var isFlipped:Bool {true}
 var backgroundClick:(()->Void)?
 override func mouseDown(with event:NSEvent) {backgroundClick?()}
}
/// Hosts controls inside the system's glass contentView, preserving their input and legibility.
final class GlassSurface:NSView {
 let content:NSView
 private let surface:NSView
 private let radius:CGFloat
 private let rim=CAGradientLayer()
 private let rimMask=CAShapeLayer()
 private var tracking:NSTrackingArea?
 private let native:Bool
 init(radius:CGFloat,clear:Bool=false){
 self.radius=radius
 let body=NSView();body.wantsLayer=true;body.layer?.backgroundColor=NSColor.clear.cgColor;content=body
 if #available(macOS 26.0,*) {
 let glass=NSGlassEffectView();glass.style=clear ? .clear:.regular;glass.cornerRadius=radius;glass.contentView=body
 glass.tintColor=NSColor.white.withAlphaComponent(clear ? 0.025:0.015)
 surface=glass;native=true
 } else {
 let effect=NSVisualEffectView();effect.material = .hudWindow;effect.blendingMode = .withinWindow;effect.state = .active;effect.wantsLayer=true;effect.layer?.cornerRadius=radius;effect.layer?.masksToBounds=true;effect.addSubview(body)
 surface=effect;native=false
 }
 super.init(frame:.zero)
 wantsLayer=true;layer?.backgroundColor=NSColor.clear.cgColor;layer?.shadowColor=NSColor.black.cgColor;layer?.shadowOpacity=native ? 0.14:0.22;layer?.shadowRadius=16;layer?.shadowOffset=NSSize(width:0,height:-5)
 addSubview(surface)
 rim.colors=[NSColor.white.withAlphaComponent(0.75).cgColor,NSColor.white.withAlphaComponent(0.07).cgColor,NSColor.white.withAlphaComponent(0.24).cgColor]
 rim.locations=[0,0.52,1];rim.startPoint=CGPoint(x:0.1,y:1);rim.endPoint=CGPoint(x:0.9,y:0);rim.opacity=native ? 0.45:0.8
 rimMask.fillColor=NSColor.clear.cgColor;rimMask.strokeColor=NSColor.white.cgColor;rimMask.lineWidth=0.8;rim.mask=rimMask;rim.zPosition=10;layer?.addSublayer(rim)
 }
 required init?(coder:NSCoder){fatalError()}
 override func layout(){
 super.layout();surface.frame=bounds;content.frame=surface.bounds
 CATransaction.begin();CATransaction.setDisableActions(true)
 rim.frame=bounds;rimMask.frame=bounds
 let path=CGPath(roundedRect:bounds.insetBy(dx:0.5,dy:0.5),cornerWidth:radius,cornerHeight:radius,transform:nil)
 rimMask.path=path;layer?.shadowPath=path
 CATransaction.commit()
 }
 override func updateTrackingAreas(){
 if let tracking {removeTrackingArea(tracking)}
 let area=NSTrackingArea(rect:.zero,options:[.mouseEnteredAndExited,.mouseMoved,.activeAlways,.inVisibleRect],owner:self,userInfo:nil);tracking=area;addTrackingArea(area);super.updateTrackingAreas()
 }
 override func mouseEntered(with event:NSEvent){rim.opacity=native ? 0.65:1}
 override func mouseExited(with event:NSEvent){rim.opacity=native ? 0.45:0.8}
 override func mouseMoved(with event:NSEvent){
 let p=convert(event.locationInWindow,from:nil);let x=min(1,max(0,p.x/max(1,bounds.width)))
 CATransaction.begin();CATransaction.setDisableActions(true);rim.startPoint=CGPoint(x:x*0.6,y:1);rim.endPoint=CGPoint(x:0.4+x*0.6,y:0);CATransaction.commit()
 }
}

final class PadView:NSView,NSSearchFieldDelegate,NSTextFieldDelegate,NSWindowDelegate {
 let store:Store
 let wallpaper=NSImageView()
 let backdrop=NSVisualEffectView()
 let tint=NSView()
 let search=NSTextField()
 let searchIcon=NSImageView()
 let clearSearchButton=NSButton()
 let searchGlass=GlassSurface(radius:22,clear:true)
 let settingsGlass=GlassSurface(radius:22,clear:true)
 let dotsGlass=GlassSurface(radius:16,clear:true)
 let canvas=Canvas()
 let dots=NSStackView()
 let status=NSTextField(labelWithString:"")
 let exitButton=NSButton()
 let settingsButton=NSButton()
 let folderTitle=NSTextField()
 let folderBack=NSButton()
 let rootSnapshot=NSImageView()
 let folderDimmer=Canvas()
 let folderPanel=GlassSurface(radius:30)
 let dragPlaceholder=NSView()
 var folderOrigin=NSRect.zero;var transitionBusy=false
 var previewOrder:[String]?;var draggedTileID:String?;var reorderTimer:Timer?
 var cachedFolderFrame=NSRect.zero
 var edgeGate=DragPageEdge();var retainedDragSource:TileButton?
 var freeDropSlot:Int?;var wallpaperKey="";var wallpaperTime=Date.distantPast
 var page=0;var folderID:String?;var selected=0;var pageSwipe=PageSwipe();var folderHomePage=0
 var dragTarget:String?;var dragHoverStart:TimeInterval=0;var dragGroupReady=false;var dragEdge=0;var dragEdgeStart:TimeInterval=0;var edgeTimer:Timer?;var hoverTimer:Timer?
 var buttons:[TileButton]=[]
 var settings:NSPanel?
 var dismiss:(()->Void)?
 var launch:((String,NSRect)->Void)?
 var launchBusy=false
 var launchGhost:NSImageView?
 var gridColumns:Int {folderID==nil ? store.layout.columns:min(5,store.layout.columns)}
 var gridRows:Int {folderID==nil ? store.layout.rows:3}
 var capacity:Int {gridColumns*gridRows}
 var entries:[Tile] {
 if let id=folderID, let t=store.layout.tiles.first(where:{$0.id==id}) {return t.paths.compactMap {store.apps[$0]}.map {Tile(id:$0.path,name:$0.name,paths:[$0.path])}}
 return store.results(search.stringValue)
 }
 var isFree:Bool {store.layout.freeLayout==true && folderID==nil && search.stringValue.isEmpty}
 var visibleEntries:[Tile] {isFree ? entries.filter { (store.layout.slots?[$0.id] ?? 0)/capacity==page }.sorted {(store.layout.slots?[$0.id] ?? 0)<(store.layout.slots?[$1.id] ?? 0)}:Array(entries.dropFirst(page*capacity).prefix(capacity))}
 var pageCount:Int {isFree ? max(1,((store.layout.slots ?? [:]).values.max() ?? 0)/capacity+2):max(1,(entries.count+capacity-1)/capacity)}
 init(store:Store) {
 self.store=store;super.init(frame:NSRect(x:0,y:0,width:1200,height:760));wantsLayer=true
 layer?.backgroundColor=NSColor.clear.cgColor
 appearance=NSAppearance(named:.darkAqua)
 wallpaper.imageScaling = .scaleAxesIndependently
 
 addSubview(wallpaper)
 backdrop.material = .hudWindow;backdrop.blendingMode = .withinWindow;backdrop.state = .active
 addSubview(backdrop);tint.wantsLayer=true;tint.layer?.backgroundColor=NSColor.black.withAlphaComponent(0.12).cgColor;addSubview(tint)
 rootSnapshot.imageScaling = .scaleAxesIndependently;rootSnapshot.isHidden=true;rootSnapshot.wantsLayer=true;addSubview(rootSnapshot)
 folderDimmer.backgroundClick = {[weak self] in self?.back()};folderDimmer.wantsLayer=true;folderDimmer.layer?.backgroundColor=NSColor.black.withAlphaComponent(0.38).cgColor;folderDimmer.isHidden=true;addSubview(folderDimmer)
 folderPanel.isHidden=true;addSubview(folderPanel)
 dragPlaceholder.wantsLayer=true;dragPlaceholder.layer?.cornerRadius=18;dragPlaceholder.layer?.backgroundColor=NSColor.white.withAlphaComponent(0.08).cgColor;dragPlaceholder.isHidden=true
 search.isEditable=true;search.isSelectable=true;search.cell?.isScrollable=true;search.placeholderString="搜索";search.delegate=self;search.focusRingType = .none;search.usesSingleLineMode=true;search.isBordered=false;search.setAccessibilityLabel("搜索应用");search.font = .systemFont(ofSize:15);search.isBezeled=false;search.drawsBackground=false;search.backgroundColor = .clear;search.textColor = .white
 addSubview(searchGlass);searchGlass.content.addSubview(search)
 searchIcon.image=NSImage(systemSymbolName:"magnifyingglass",accessibilityDescription:nil);searchIcon.contentTintColor=NSColor.white.withAlphaComponent(0.75);searchIcon.setAccessibilityElement(false);searchGlass.content.addSubview(searchIcon)
 clearSearchButton.image=NSImage(systemSymbolName:"xmark.circle.fill",accessibilityDescription:"清空搜索");clearSearchButton.isBordered=false;clearSearchButton.contentTintColor=NSColor.white.withAlphaComponent(0.65);clearSearchButton.target=self;clearSearchButton.action=#selector(clearSearch);clearSearchButton.isHidden=true;clearSearchButton.setAccessibilityLabel("清空搜索");searchGlass.content.addSubview(clearSearchButton)
 settingsButton.image=NSImage(systemSymbolName:"gearshape",accessibilityDescription:"设置");settingsButton.bezelStyle = .inline;settingsButton.target=self;settingsButton.action=#selector(showSettings);settingsButton.toolTip="设置";settingsButton.isBordered=false;settingsButton.contentTintColor = .white;addSubview(settingsGlass);settingsGlass.content.addSubview(settingsButton)
 exitButton.isHidden=true;status.isHidden=true
 exitButton.title="退出";exitButton.bezelStyle = .inline;exitButton.contentTintColor = .white;exitButton.target=self;exitButton.action=#selector(quit);exitButton.toolTip="退出（Esc 或 ⌘Q）";addSubview(exitButton)
 addSubview(canvas);canvas.addSubview(dragPlaceholder);registerForDraggedTypes([.launcherTile]);canvas.backgroundClick = {[weak self] in self?.escape()}
 dots.orientation = .horizontal;dots.spacing=11;addSubview(dotsGlass);dotsGlass.content.addSubview(dots)
 status.textColor = .white.withAlphaComponent(0.65);status.font = .systemFont(ofSize:11);status.alignment = .center;addSubview(status)
 folderTitle.isEditable=true;folderTitle.isSelectable=true;folderTitle.usesSingleLineMode=true;folderTitle.cell?.isScrollable=true;folderTitle.setAccessibilityLabel("文件夹名称");folderTitle.placeholderString="文件夹名称";folderTitle.font = .systemFont(ofSize:26,weight:.medium);folderTitle.alignment = .center;folderTitle.textColor = .white;folderTitle.isBezeled=false;folderTitle.drawsBackground=false;folderTitle.delegate=self;addSubview(folderTitle)
 folderBack.title="‹ 返回";folderBack.bezelStyle = .inline;folderBack.contentTintColor = .white;folderBack.target=self;folderBack.action=#selector(back);addSubview(folderBack)
 store.layout.syncSlots();rebuild(animated:false)
 }
 func refreshWallpaper(screen:NSScreen,force:Bool=true) {
 guard let file=SystemWallpaper.shared.file(for:screen) else {
 wallpaper.image=nil;wallpaperKey="";backdrop.blendingMode = .behindWindow;needsLayout=true;return
 }
 let key=file.fingerprint+"|"+String(store.layout.blur)+"|"+NSApp.effectiveAppearance.name.rawValue
 if !force,key==wallpaperKey {return}
 // Read data rather than NSImage(contentsOf:) to avoid stale images cached at the same path.
 guard let data=try? Data(contentsOf:file.url),let source=NSImage(data:data) else{return}
 wallpaperKey=key;wallpaperTime=Date()
 if store.layout.blur,let tiff=source.tiffRepresentation,let ci=CIImage(data:tiff) {
 let scale=max(1,source.size.width/max(1,screen.frame.width))
 let blurred=ci.clampedToExtent().applyingFilter("CIGaussianBlur",parameters:[kCIInputRadiusKey:16*scale]).cropped(to:ci.extent)
 if let cg=CIContext(options:[.useSoftwareRenderer:false]).createCGImage(blurred,from:ci.extent) {wallpaper.image=NSImage(cgImage:cg,size:source.size)} else {wallpaper.image=source}
 } else {wallpaper.image=source}
 wallpaper.setAccessibilityLabel("背景："+file.kind)
 needsLayout=true
 }
 required init?(coder:NSCoder) {fatalError()}
 override var acceptsFirstResponder:Bool {true}
 override func layout() {
 super.layout();wallpaper.frame=bounds;backdrop.frame=bounds;tint.frame=bounds;backdrop.isHidden = wallpaper.image != nil || !store.layout.blur
 let top=bounds.height-82
 searchGlass.frame=NSRect(x:bounds.midX-182,y:top,width:310,height:44)
 settingsGlass.frame=NSRect(x:searchGlass.frame.maxX+10,y:top,width:44,height:44)
 searchGlass.layoutSubtreeIfNeeded();settingsGlass.layoutSubtreeIfNeeded()
 searchIcon.frame=NSRect(x:16,y:14,width:16,height:16)
 search.frame=NSRect(x:40,y:8,width:230,height:28)
 clearSearchButton.frame=NSRect(x:280,y:13,width:18,height:18)
 settingsButton.frame=NSRect(x:9,y:9,width:26,height:26)
 exitButton.frame=NSRect(x:bounds.width-72,y:top,width:50,height:28)
 folderTitle.frame=NSRect(x:bounds.midX-220,y:bounds.height-130,width:440,height:38)
 folderBack.frame=NSRect(x:48,y:bounds.height-120,width:80,height:30)
 let margin=max(42,bounds.width*0.075)
 if folderID==nil {
 canvas.frame=NSRect(x:margin,y:90,width:max(1,bounds.width-margin*2),height:max(1,bounds.height-210))
 } else {
 let width=min(920,bounds.width*0.78)
 let rows=max(1,min(gridRows,(min(entries.count,capacity)+gridColumns-1)/gridColumns))
 let height=min(bounds.height-180,CGFloat(rows)*145+120)
 let panelRect=NSRect(x:bounds.midX-width/2,y:bounds.midY-height/2,width:width,height:height)
 folderPanel.frame=panelRect;cachedFolderFrame=panelRect
 folderPanel.layoutSubtreeIfNeeded()
 canvas.frame=NSRect(x:32,y:44,width:panelRect.width-64,height:panelRect.height-104)
 folderTitle.frame=NSRect(x:95,y:panelRect.height-57,width:panelRect.width-190,height:35)
 folderBack.frame=NSRect(x:16,y:panelRect.height-54,width:75,height:30)
 }
 folderDimmer.frame=bounds
 let cols=gridColumns,rows=folderID==nil ? gridRows:max(1,min(gridRows,(min(entries.count,capacity)+gridColumns-1)/gridColumns))
 let cw=canvas.bounds.width/CGFloat(cols),ch=canvas.bounds.height/CGFloat(rows)
 for (originalIndex,b) in buttons.enumerated() {
 let i=isFree ? ((store.layout.slots?[b.tile.id] ?? 0)%capacity):(previewOrder?.firstIndex(of:b.tile.id) ?? originalIndex)
 let iconSize=min(store.layout.iconSize,max(32,ch-38))
 if let image=b.subviews.compactMap({$0 as? NSImageView}).first {for c in image.constraints where c.firstAttribute == .width || c.firstAttribute == .height {c.constant=iconSize}}
 b.frame=NSRect(x:CGFloat(i%cols)*cw+6,y:CGFloat(i/cols)*ch+2,width:max(1,cw-12),height:max(1,ch-4))}
 let dotsWidth=CGFloat(pageCount*19)+28
 dotsGlass.frame=NSRect(x:bounds.midX-dotsWidth/2,y:44,width:dotsWidth,height:32);dotsGlass.layoutSubtreeIfNeeded()
 dots.frame=NSRect(x:14,y:7,width:CGFloat(pageCount*19),height:18)
 status.frame=NSRect(x:40,y:23,width:bounds.width-80,height:18)
 if let id=draggedTileID,let i=freeDropSlot ?? previewOrder?.firstIndex(of:id) ?? buttons.firstIndex(where:{$0.tile.id==id}) {dragPlaceholder.frame=NSRect(x:CGFloat(i%cols)*cw+12,y:CGFloat(i/cols)*ch+8,width:cw-24,height:ch-16)}
 }
 func icon(_ tile:Tile)->NSImage {
 if tile.paths.count==1 {return store.apps[tile.paths[0]]?.icon ?? NSImage()}
 let image=NSImage(size:NSSize(width:128,height:128));image.lockFocus()
 let shape=NSBezierPath(roundedRect:NSRect(x:5,y:5,width:118,height:118),xRadius:25,yRadius:25)
 NSGradient(starting:NSColor.white.withAlphaComponent(0.32),ending:NSColor.white.withAlphaComponent(0.10))?.draw(in:shape,angle:-75)
 NSColor.white.withAlphaComponent(0.48).setStroke();shape.lineWidth=0.8;shape.stroke()
 for (i,p) in tile.paths.prefix(9).enumerated() {store.apps[p]?.icon.draw(in:NSRect(x:17+(i%3)*33,y:81-(i/3)*33,width:29,height:29))}
 image.unlockFocus();return image
 }
 func rebuild(animated:Bool=true,direction:Int=0) {
 for t in store.layout.tiles where t.paths.count==1 {if let i=store.layout.tiles.firstIndex(where:{$0.id==t.id}),let app=store.apps[t.paths[0]] {store.layout.tiles[i].name=app.name}}

 let oldFrames=Dictionary(uniqueKeysWithValues:buttons.map {($0.tile.id,$0.frame)})
 let oldContext=folderPanel.isHidden
 page=min(max(0,page),pageCount-1)
 clearSearchButton.isHidden=search.stringValue.isEmpty
 buttons.forEach {$0.removeFromSuperview()};buttons=[]
 folderPanel.isHidden=folderID==nil;rootSnapshot.isHidden=folderID==nil;folderDimmer.isHidden=folderID==nil
 searchGlass.isHidden=folderID != nil;settingsGlass.isHidden=folderID != nil
 if folderID != nil {
 if canvas.superview !== folderPanel.content {folderPanel.content.addSubview(canvas);folderPanel.content.addSubview(folderTitle);folderPanel.content.addSubview(folderBack)}
 } else {
 if canvas.superview !== self {addSubview(canvas,positioned:.above,relativeTo:folderPanel);addSubview(folderTitle);addSubview(folderBack)}
 }
 folderTitle.isHidden=folderID==nil;folderBack.isHidden=folderID==nil;search.isHidden=folderID != nil;settingsButton.isHidden=folderID != nil
 if let id=folderID {folderTitle.stringValue=store.layout.tiles.first(where:{$0.id==id})?.name ?? "文件夹"}
 for t in visibleEntries {
 let b=TileButton();b.tile=t;b.pad=self;b.isBordered=false;b.wantsLayer=true;b.layer?.cornerRadius=12
 b.title="";b.target=self;b.action=#selector(buttonActivate(_:));b.toolTip=t.name;b.setAccessibilityLabel(t.name)
 let img=NSImageView();img.image=icon(t);img.imageScaling = .scaleProportionallyUpOrDown;img.translatesAutoresizingMaskIntoConstraints=false
 let label=NSTextField(labelWithString:t.name);label.textColor = .white;label.alignment = .center;label.font = .systemFont(ofSize:13);label.lineBreakMode = .byTruncatingTail;label.translatesAutoresizingMaskIntoConstraints=false
 b.addSubview(img);b.addSubview(label)
 let halo=NSView();halo.identifier=NSUserInterfaceItemIdentifier("folderHalo");halo.wantsLayer=true;halo.layer?.cornerRadius=22;halo.layer?.backgroundColor=NSColor.white.withAlphaComponent(0.18).cgColor;halo.alphaValue=0;halo.translatesAutoresizingMaskIntoConstraints=false;b.addSubview(halo,positioned:.below,relativeTo:img)
 NSLayoutConstraint.activate([halo.centerXAnchor.constraint(equalTo:img.centerXAnchor),halo.centerYAnchor.constraint(equalTo:img.centerYAnchor),halo.widthAnchor.constraint(equalTo:img.widthAnchor,constant:20),halo.heightAnchor.constraint(equalTo:img.heightAnchor,constant:20)])
 let size=min(store.layout.iconSize,max(32,(canvas.bounds.height/CGFloat(gridRows))-36))
 NSLayoutConstraint.activate([img.centerXAnchor.constraint(equalTo:b.centerXAnchor),img.centerYAnchor.constraint(equalTo:b.centerYAnchor,constant:-10),img.widthAnchor.constraint(equalToConstant:size),img.heightAnchor.constraint(equalToConstant:size),label.topAnchor.constraint(equalTo:img.bottomAnchor,constant:8),label.leadingAnchor.constraint(equalTo:b.leadingAnchor,constant:3),label.trailingAnchor.constraint(equalTo:b.trailingAnchor,constant:-3)])
 canvas.addSubview(b);buttons.append(b)
 }
 for v in dots.arrangedSubviews {dots.removeArrangedSubview(v);v.removeFromSuperview()}
 for i in 0..<pageCount {let b=NSButton(title:i==page ? "●":"○",target:self,action:#selector(dot(_:)));b.tag=i;b.isBordered=false;b.font = .systemFont(ofSize:12);b.contentTintColor = .white.withAlphaComponent(i==page ? 1:0.45);b.translatesAutoresizingMaskIntoConstraints=false;b.widthAnchor.constraint(equalToConstant:8).isActive=true;dots.addArrangedSubview(b)}
 status.stringValue=entries.isEmpty ? "没有找到应用" : "\(entries.count) 个\(folderID == nil ? "项目" : "应用")  ·  \(page+1) / \(pageCount)"
 needsLayout=true;layoutSubtreeIfNeeded()
 if animated {
 if direction != 0 {
 let slide=CABasicAnimation(keyPath:"transform.translation.x");slide.fromValue=CGFloat(direction)*min(160,canvas.bounds.width*0.12);slide.toValue=0;slide.duration=0.28;slide.timingFunction=CAMediaTimingFunction(controlPoints:0.2,0.8,0.2,1);canvas.wantsLayer=true;canvas.layer?.add(slide,forKey:"page")
 } else if oldContext == (folderID==nil) {
 for b in buttons {if let old=oldFrames[b.tile.id],old != b.frame {animateMove(b,from:old,to:b.frame)} else if oldFrames[b.tile.id]==nil {let pop=CASpringAnimation(keyPath:"transform.scale");pop.fromValue=0.82;pop.toValue=1;pop.mass=1;pop.stiffness=320;pop.damping=29;pop.duration=0.3;b.layer?.add(pop,forKey:"insert")}}
 }
 }

 }
 func escape() {if settings?.isVisible == true {settings?.close()} else if folderID != nil {back()} else if !search.stringValue.isEmpty {search.stringValue="";page=0;rebuild()} else {dismiss?()}}
 @objc func quit(){dismiss?()}
 @objc func back(){
 guard !transitionBusy,folderID != nil else{return}
 window?.makeFirstResponder(self)
 transitionBusy=true
 let frame=cachedFolderFrame
 let sx=max(0.04,folderOrigin.width/max(1,frame.width)),sy=max(0.04,folderOrigin.height/max(1,frame.height))
 let scale=CABasicAnimation(keyPath:"transform.scale");scale.fromValue=1;scale.toValue=min(sx,sy)
 let move=CABasicAnimation(keyPath:"position");move.fromValue=NSValue(point:folderPanel.layer?.position ?? NSPoint(x:frame.midX,y:frame.midY));move.toValue=NSValue(point:NSPoint(x:folderOrigin.midX,y:folderOrigin.midY))
 let fade=CABasicAnimation(keyPath:"opacity");fade.fromValue=1;fade.toValue=0
 let group=CAAnimationGroup();group.animations=[scale,move,fade];group.duration=0.24;group.timingFunction=CAMediaTimingFunction(controlPoints:0.2,0.75,0.25,1);group.fillMode = .forwards;group.isRemovedOnCompletion=false;folderPanel.layer?.add(group,forKey:"glassCollapse")
 NSAnimationContext.runAnimationGroup({context in context.duration=0.24;folderDimmer.animator().alphaValue=0},completionHandler:{[weak self] in
 guard let self else{return}
 self.folderPanel.layer?.removeAnimation(forKey:"glassCollapse");self.folderPanel.layer?.transform=CATransform3DIdentity;self.folderDimmer.alphaValue=1
 self.folderID=nil;self.page=self.folderHomePage;self.previewOrder=nil;self.rebuild(animated:false);self.transitionBusy=false;self.window?.makeFirstResponder(self.search)
 })
 }
 @objc func dot(_ b:NSButton){let d=b.tag-page;page=b.tag;rebuild(direction:d)}
 @objc func buttonActivate(_ sender:TileButton){activate(sender.tile)}
 func activate(_ t:Tile) {
 guard !launchBusy else{return}
 if t.paths.count>1 {
 guard !transitionBusy else{return}
 if let b=buttons.first(where:{$0.tile.id==t.id}),let img=b.subviews.compactMap({$0 as? NSImageView}).first {folderOrigin=img.convert(img.bounds,to:self)} else {folderOrigin=NSRect(x:bounds.midX-40,y:bounds.midY-40,width:80,height:80)}
 rootSnapshot.frame=canvas.frame
 if let bitmap=canvas.bitmapImageRepForCachingDisplay(in:canvas.bounds) {canvas.cacheDisplay(in:canvas.bounds,to:bitmap);let image=NSImage(size:canvas.bounds.size);image.addRepresentation(bitmap);rootSnapshot.image=image}
 folderHomePage=page;folderID=t.id;page=0;rebuild(animated:false);window?.makeFirstResponder(self)
 animateFolderOpen()
 }
 else if let path=t.paths.first {
 let button=buttons.first { $0.tile.id==t.id || $0.tile.paths==t.paths }
 let image=button?.subviews.compactMap {$0 as? NSImageView}.first
 let origin=image.map {$0.convert($0.bounds,to:self)} ?? NSRect(x:bounds.midX-38,y:bounds.midY-38,width:76,height:76)
 launch?(path,origin)
 }
 }
 @objc func clearSearch(){search.stringValue="";page=0;selected=0;rebuild(animated:false);window?.makeFirstResponder(search)}
 func controlTextDidChange(_ obj:Notification) {if obj.object as AnyObject? === search {page=0;selected=0;rebuild(animated:false)}}
 func controlTextDidEndEditing(_ obj:Notification) {
 if obj.object as AnyObject? === folderTitle,let id=folderID,let i=store.layout.tiles.firstIndex(where:{$0.id==id}) {let n=folderTitle.stringValue.trimmingCharacters(in:.whitespaces);store.layout.tiles[i].name=n.isEmpty ? "文件夹":n;store.save()}
 }
 func control(_ control:NSControl,textView:NSTextView,doCommandBy selector:Selector)->Bool {
 if selector == #selector(NSResponder.cancelOperation(_:)),control !== folderTitle {escape();return true}
 if control === folderTitle {
 if selector == #selector(NSResponder.insertNewline(_:)) || selector == #selector(NSResponder.cancelOperation(_:)) {window?.makeFirstResponder(self);return true}
 return false
 }
 if selector == #selector(NSResponder.insertNewline(_:)) {if let first=entries.first {activate(first)};return true}
 return false
 }
 override func keyDown(with e:NSEvent) {
 switch e.keyCode {
 case 53:escape()
 case 123:changePage(-1)
 case 124:changePage(1)
 case 36:if let first=entries.dropFirst(page*capacity).first {activate(first)}
 default:if let s=e.characters,!e.modifierFlags.contains(.command) {search.stringValue+=s;window?.makeFirstResponder(search);page=0;rebuild(animated:false)} else {super.keyDown(with:e)}
 }
 }
 func changePage(_ delta:Int) {let next=min(pageCount-1,max(0,page+delta));guard next != page else{return};page=next;rebuild(direction:delta)}
 override func scrollWheel(with e:NSEvent) {
 let phase=e.phase
 let phased = !phase.isEmpty
 if let delta=pageSwipe.feed(x:Double(e.scrollingDeltaX),y:Double(e.scrollingDeltaY),precise:e.hasPreciseScrollingDeltas,begin:phase.contains(.began),end:phase.contains(.ended),cancel:phase.contains(.cancelled),momentum:!e.momentumPhase.isEmpty,phased:phased,time:e.timestamp) {changePage(delta)}
 }
 override func rightMouseDown(with e:NSEvent) {let menu=NSMenu();let item=NSMenuItem(title:"设置…",action:#selector(showSettings),keyEquivalent:"");item.target=self;menu.addItem(item);let q=NSMenuItem(title:"退出",action:#selector(quit),keyEquivalent:"");q.target=self;menu.addItem(q);NSMenu.popUpContextMenu(menu,with:e,for:self)}
 func dragPayload(_ info:NSDraggingInfo)->TileDrag? {guard let data=info.draggingPasteboard.data(forType:.launcherTile) else{return nil};return try? JSONDecoder().decode(TileDrag.self,from:data)}
 override func draggingEntered(_ sender:NSDraggingInfo)->NSDragOperation {draggingUpdated(sender)}
 override func draggingUpdated(_ sender:NSDraggingInfo)->NSDragOperation {
 guard search.stringValue.isEmpty,let payload=dragPayload(sender) else{return []}
 let point=convert(sender.draggingLocation,from:nil)
 let local=canvas.convert(point,from:self)
 if !isFree,previewOrder==nil,draggedTileID != nil {previewOrder=buttons.map {$0.tile.id};if !previewOrder!.contains(payload.tile.id) {previewOrder!.append(payload.tile.id)}}
 let target=buttons.first(where:{$0.frame.contains(local) && $0.tile.id != payload.tile.id})
 let center=target.map {$0.frame.insetBy(dx:$0.frame.width*0.30,dy:$0.frame.height*0.20).contains(local)} ?? false
 let hover=center ? target?.tile.id:nil
 if hover != dragTarget {
 hoverTimer?.invalidate();dragTarget=hover;dragGroupReady=false
 clearGroupHighlight()
 if let hover,folderID==nil {
 hoverTimer=Timer(timeInterval:0.65,repeats:false) {[weak self] _ in
 guard let self,self.dragTarget==hover else{return};self.dragGroupReady=true
 if let b=self.buttons.first(where:{$0.tile.id==hover}) {b.subviews.first(where:{$0.identifier?.rawValue=="folderHalo"})?.animator().alphaValue=1
 let spring=CASpringAnimation(keyPath:"transform.scale");spring.fromValue=1;spring.toValue=1.07;spring.stiffness=340;spring.damping=27;spring.duration=0.28;spring.fillMode = .forwards;spring.isRemovedOnCompletion=false;b.layer?.add(spring,forKey:"groupReady")}
 }
 if let hoverTimer {RunLoop.main.add(hoverTimer,forMode:.common)}
 }
 }
 if isFree {
 freeDropSlot=gridSlot(at:local);needsLayout=true
 } else if !center,let target,target.tile.id != payload.tile.id {
 scheduleReorder(source:payload.tile.id,target:target.tile.id)
 } else {reorderTimer?.invalidate();reorderTimer=nil}
 updateDragEdge(point:point)
 return .move
 }
 override func wantsPeriodicDraggingUpdates()->Bool {true}
 override func draggingExited(_ sender:NSDraggingInfo?){
 hoverTimer?.invalidate();hoverTimer=nil;reorderTimer?.invalidate();reorderTimer=nil;dragTarget=nil;dragGroupReady=false;clearGroupHighlight()
 // The source continues tracking even when the pointer is on the screen boundary.
 trackDraggingPointer(NSEvent.mouseLocation)
 }
 override func prepareForDragOperation(_ sender:NSDraggingInfo)->Bool {dragPayload(sender) != nil}
 override func performDragOperation(_ sender:NSDraggingInfo)->Bool {
 guard let payload=dragPayload(sender),search.stringValue.isEmpty else{return false}
 let point=convert(sender.draggingLocation,from:nil)
 let local=canvas.convert(point,from:self)
 let target=buttons.first(where:{$0.frame.contains(local)})
 let nextID: String? = {
 guard let previewOrder,let i=previewOrder.firstIndex(of:payload.tile.id),i+1<previewOrder.count else{return nil};return previewOrder[i+1]
 }()
 if isFree {
 let slot=page*capacity+gridSlot(at:local)
 store.layout.moveFree(payload.tile,from:payload.folder,to:slot,group:dragGroupReady ? target?.tile.id:nil)
 } else if let folder=folderID {
 guard payload.folder==folder,let path=payload.tile.paths.first else{return false}
 if canvas.convert(canvas.bounds,to:self).contains(point) {
 store.layout.reorderInFolder(folder,path:path,before:previewOrder != nil ? nextID:target?.tile.paths.first)
 } else {
 let index=(store.layout.tiles.firstIndex(where:{$0.id==folder}) ?? 0)+1
 store.layout.place(payload.tile,from:folder,target:nil,group:false,index:index)
 folderID=nil;page=folderHomePage
 }
 } else {
 let targetID=dragGroupReady ? target?.tile.id:(previewOrder != nil ? nextID:target?.tile.id)
 let index=min(store.layout.tiles.count,(page+1)*capacity)
 store.layout.place(payload.tile,from:payload.folder,target:targetID,group:dragGroupReady && dragTarget==targetID,index:index)
 }
 let grouping=dragGroupReady
 endTileDrag(restore:false);store.save();rebuild()
 if grouping,let targetID=target?.tile.id,let b=buttons.first(where:{$0.tile.id==targetID}) {let pulse=CASpringAnimation(keyPath:"transform.scale");pulse.fromValue=1.15;pulse.toValue=1;pulse.stiffness=300;pulse.damping=24;pulse.duration=0.35;b.layer?.add(pulse,forKey:"groupCreated")}
 return true
 }
 func animateMove(_ view:NSView,from:NSRect,to:NSRect) {
 guard from != to else{return}
 let move=CASpringAnimation(keyPath:"position");move.fromValue=NSValue(point:NSPoint(x:from.minX,y:from.minY));move.toValue=NSValue(point:NSPoint(x:to.minX,y:to.minY));move.mass=1;move.stiffness=330;move.damping=31;move.duration=0.32
 // Position is expressed using the actual layer anchor, which AppKit may adjust.
 if let layer=view.layer {let anchor=layer.anchorPoint;move.fromValue=NSValue(point:NSPoint(x:from.minX+from.width*anchor.x,y:from.minY+from.height*anchor.y));move.toValue=NSValue(point:layer.position);layer.add(move,forKey:"reorder")}
 }
 func gridSlot(at point:NSPoint)->Int {let column=min(gridColumns-1,max(0,Int(point.x/max(1,canvas.bounds.width/CGFloat(gridColumns)))));let row=min(gridRows-1,max(0,Int(point.y/max(1,canvas.bounds.height/CGFloat(gridRows)))));return row*gridColumns+column}
 func beginTileDrag(id:String,source:TileButton) {retainedDragSource=source;edgeGate.reset();startDragPageTracking();draggedTileID=id;previewOrder=isFree ? nil:buttons.map {$0.tile.id};freeDropSlot=isFree ? ((store.layout.slots?[id] ?? 0)%capacity):nil;dragPlaceholder.isHidden=false;needsLayout=true}
 func startDragPageTracking(){
 edgeTimer?.invalidate()
 let timer=Timer(timeInterval:0.04,repeats:true) {[weak self] _ in guard let self,self.draggedTileID != nil else{return};self.trackDraggingPointer(NSEvent.mouseLocation)}
 edgeTimer=timer
 RunLoop.main.add(timer,forMode:.common)
 RunLoop.main.add(timer,forMode:.eventTracking)
 }
 func trackDraggingPointer(_ screenPoint:NSPoint){
 guard draggedTileID != nil,let window else{return}
 updateDragEdge(point:convert(window.convertPoint(fromScreen:screenPoint),from:nil))
 }
 func updateDragEdge(point:NSPoint){
 guard draggedTileID != nil,let direction=edgeGate.update(x:Double(point.x),y:Double(point.y),width:Double(bounds.width),height:Double(bounds.height),time:ProcessInfo.processInfo.systemUptime) else{return}
 let old=page
 let next=min(pageCount-1,max(0,page+direction))
 guard next != old else{return}
 hoverTimer?.invalidate();hoverTimer=nil;reorderTimer?.invalidate();reorderTimer=nil;dragTarget=nil;dragGroupReady=false;clearGroupHighlight()
 // Never carry the source page's insertion order onto the destination page.
 previewOrder=nil;freeDropSlot=nil;page=next;rebuild(direction:direction)
 if isFree {freeDropSlot=gridSlot(at:canvas.convert(point,from:self))}
 }
 func clearGroupHighlight(){for b in buttons {b.layer?.borderWidth=0;b.subviews.first(where:{$0.identifier?.rawValue=="folderHalo"})?.alphaValue=0;b.layer?.removeAnimation(forKey:"groupReady")}}
 func scheduleReorder(source:String,target:String) {
 guard reorderTimer==nil,let order=previewOrder,order.contains(source),source != target else{return}
 reorderTimer=Timer(timeInterval:0.12,repeats:false) {[weak self] _ in
 guard let self,var order=self.previewOrder,let from=order.firstIndex(of:source),let to=order.firstIndex(of:target) else{return}
 self.reorderTimer=nil;order.remove(at:from);order.insert(source,at:min(to,order.count));self.previewOrder=order
 let old=Dictionary(uniqueKeysWithValues:self.buttons.map {($0.tile.id,$0.frame)})
 self.needsLayout=true;self.layoutSubtreeIfNeeded()
 for b in self.buttons where b.tile.id != source {if let frame=old[b.tile.id] {self.animateMove(b,from:frame,to:b.frame)}}
 }
 if let reorderTimer {RunLoop.main.add(reorderTimer,forMode:.common)}
 }
 func animateFolderOpen(){
 let rect=cachedFolderFrame
 func expand(_ view:NSView){
 view.wantsLayer=true
 view.layer?.anchorPoint=CGPoint(x:0.5,y:0.5);view.layer?.position=CGPoint(x:rect.midX,y:rect.midY)
 let transform=CABasicAnimation(keyPath:"transform");let sx=max(0.08,folderOrigin.width/rect.width),sy=max(0.08,folderOrigin.height/rect.height)
 // Explicit position animation keeps the expansion rooted at the selected icon.
 let move=CABasicAnimation(keyPath:"position");if let l=view.layer {let origin=l.position;move.fromValue=NSValue(point:NSPoint(x:origin.x+folderOrigin.midX-rect.midX,y:origin.y+folderOrigin.midY-rect.midY));move.toValue=NSValue(point:origin)}
 transform.fromValue=NSValue(caTransform3D:CATransform3DMakeScale(sx,sy,1));transform.toValue=NSValue(caTransform3D:CATransform3DIdentity)
 let group=CAAnimationGroup();group.animations=[transform,move];group.duration=0.28;group.timingFunction=CAMediaTimingFunction(controlPoints:0.18,0.8,0.25,1);view.layer?.add(group,forKey:"folderExpand")
 }
 expand(folderPanel)
 let fade=CABasicAnimation(keyPath:"opacity");fade.fromValue=0;fade.toValue=1;fade.duration=0.25;canvas.layer?.add(fade,forKey:"folderContents");folderTitle.wantsLayer=true;folderTitle.layer?.add(fade,forKey:"folderTitle");folderDimmer.layer?.add(fade,forKey:"folderDim")
 for (index,b) in buttons.enumerated() {let pop=CABasicAnimation(keyPath:"transform.translation.y");pop.fromValue = -12;pop.toValue=0;pop.duration=0.25;pop.beginTime=CACurrentMediaTime()+Double(index%gridColumns)*0.012;pop.fillMode = .backwards;pop.timingFunction=CAMediaTimingFunction(name:.easeOut);b.layer?.add(pop,forKey:"folderItem")}
 }
 func endTileDrag(restore:Bool=true){
 hoverTimer?.invalidate();edgeTimer?.invalidate();reorderTimer?.invalidate();hoverTimer=nil;edgeTimer=nil;reorderTimer=nil;dragTarget=nil;dragGroupReady=false;dragEdge=0;edgeGate.reset()
 clearGroupHighlight();buttons.forEach {$0.alphaValue=1};dragPlaceholder.isHidden=true;draggedTileID=nil;freeDropSlot=nil
 if restore,previewOrder != nil {let old=Dictionary(uniqueKeysWithValues:buttons.map {($0.tile.id,$0.frame)});previewOrder=nil;needsLayout=true;layoutSubtreeIfNeeded();for b in buttons {if let f=old[b.tile.id] {animateMove(b,from:f,to:b.frame)}}} else {previewOrder=nil}
 }
 @objc func extractTile(_ sender:NSMenuItem) {
 guard let folder=folderID,let path=sender.representedObject as? String,let app=store.apps[path] else{return}
 let index=(store.layout.tiles.firstIndex(where:{$0.id==folder}) ?? 0)+1
 store.layout.place(Tile(name:app.name,paths:[path]),from:folder,target:nil,group:false,index:index)
 folderID=nil;page=folderHomePage;store.save();rebuild()
 }
 @objc func menuOpen(_ sender:NSMenuItem){if let t=entries.first(where:{$0.id==sender.representedObject as? String}) {activate(t)}}
 @objc func hideTile(_ sender:NSMenuItem){guard let i=store.layout.tiles.firstIndex(where:{$0.id==sender.representedObject as? String}) else{return};store.layout.hidden+=store.layout.tiles.remove(at:i).paths;store.save();rebuild()}
 @objc func ungroup(_ sender:NSMenuItem){guard let i=store.layout.tiles.firstIndex(where:{$0.id==sender.representedObject as? String}) else{return};let t=store.layout.tiles.remove(at:i);store.layout.tiles.insert(contentsOf:t.paths.compactMap {store.apps[$0]}.map {Tile(name:$0.name,paths:[$0.path])},at:i);store.save();rebuild()}
 @objc func showSettings() {
 if let settings,settings.isVisible {presentSettings(settings);return}
 let panel=NSPanel(contentRect:NSRect(x:0,y:0,width:480,height:480),styleMask:[.titled,.closable],backing:.buffered,defer:false);panel.title="启动台设置";panel.appearance=NSAppearance(named:.darkAqua);panel.isReleasedWhenClosed=false
 panel.isOpaque=false;panel.backgroundColor = .clear;panel.titlebarAppearsTransparent=true;panel.styleMask.insert(.fullSizeContentView)
 let settingsSurface=GlassSurface(radius:18);settingsSurface.frame=NSRect(x:0,y:0,width:480,height:480);panel.contentView=settingsSurface;settingsSurface.layoutSubtreeIfNeeded()
 let content=settingsSurface.content
 func label(_ text:String,_ y:CGFloat){let l=NSTextField(labelWithString:text);l.frame=NSRect(x:28,y:y,width:430,height:24);content.addSubview(l)}
 label("布局与外观",435)
 let free=NSButton(checkboxWithTitle:"自由布局（保留图标空位）",target:self,action:#selector(toggleFree(_:)));free.state=store.layout.freeLayout==true ? .on:.off;free.frame=NSRect(x:28,y:391,width:400,height:26);content.addSubview(free)
 let hint=NSTextField(labelWithString:"开启后可放到任意格子，中间空位会保留。");hint.font = .systemFont(ofSize:11);hint.textColor = .secondaryLabelColor;hint.frame=NSRect(x:48,y:370,width:405,height:18);content.addSubview(hint)
 let follow=NSButton(checkboxWithTitle:"跟随系统当前桌面壁纸",target:self,action:#selector(toggleFollow(_:)));follow.state=store.layout.followWallpaper != false ? .on:.off;follow.frame=NSRect(x:28,y:336,width:400,height:26);content.addSubview(follow)
 for (index,text) in ["列数","行数","图标大小"].enumerated() {
 let y=CGFloat(300-index*48);label(text,y)
 let slider=NSSlider(value:index==0 ? Double(store.layout.columns):index==1 ? Double(store.layout.rows):store.layout.iconSize,minValue:index==2 ? 40:3,maxValue:index==2 ? 110:index==0 ? 10:7,target:self,action:#selector(adjust(_:)));slider.tag=index;slider.frame=NSRect(x:125,y:y,width:250,height:24);if index<2 {slider.numberOfTickMarks=index==0 ? 8:5;slider.allowsTickMarkValuesOnly=true};content.addSubview(slider)
 }
 let blur=NSButton(checkboxWithTitle:"模糊背景",target:self,action:#selector(toggleBlur(_:)));blur.state=store.layout.blur ? .on:.off;blur.frame=NSRect(x:28,y:145,width:200,height:25);content.addSubview(blur)
 let restore=NSButton(title:"恢复隐藏的应用",target:self,action:#selector(restoreHidden));restore.frame=NSRect(x:28,y:98,width:170,height:30);content.addSubview(restore)
 let reset=NSButton(title:"重新扫描应用",target:self,action:#selector(rescan));reset.frame=NSRect(x:210,y:98,width:170,height:30);content.addSubview(reset)
 label("拖动排序；在图标中央停留后松手：建立文件夹",53)
 label("Esc 返回或关闭 · ⌘Q 退出 · 左右键 / 滚动翻页",26)
 settings=panel;presentSettings(panel)
 }
 func prepareLaunch(path:String,origin:NSRect){
 launchBusy=true
 launchGhost?.removeFromSuperview()
 let ghost=NSImageView(frame:origin);ghost.image=store.apps[path]?.icon;ghost.imageScaling = .scaleProportionallyUpOrDown;ghost.wantsLayer=true
 addSubview(ghost);launchGhost=ghost
 // Keep the selected icon independent from the grid as the rest of the page leaves.
 for b in buttons where b.tile.paths==[path] {b.alphaValue=0}
 ghost.layer?.anchorPoint=CGPoint(x:0.5,y:0.5);ghost.layer?.position=CGPoint(x:origin.midX,y:origin.midY)
 guard !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else{return}
 let zoom=CAKeyframeAnimation(keyPath:"transform.scale");zoom.values=[0.96,1.12,1.42];zoom.keyTimes=[0,0.28,1];zoom.duration=0.29;zoom.timingFunctions=[CAMediaTimingFunction(controlPoints:0.2,0.8,0.25,1),CAMediaTimingFunction(controlPoints:0.25,0.1,0.5,1)];zoom.fillMode = .forwards;zoom.isRemovedOnCompletion=false;ghost.layer?.add(zoom,forKey:"launchIcon")
 }
 func prepareExit(launching:Bool){
 guard !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else{return}
 canvas.wantsLayer=true
 let rect=canvas.frame
 canvas.layer?.anchorPoint=CGPoint(x:0.5,y:0.5);canvas.layer?.position=CGPoint(x:rect.midX,y:rect.midY)
 let zoom=CABasicAnimation(keyPath:"transform.scale");zoom.fromValue=(canvas.layer?.presentation()?.value(forKeyPath:"transform.scale") as? NSNumber)?.doubleValue ?? 1;zoom.toValue=launching ? 1.055:1.10;zoom.duration=launching ? 0.25:0.23;zoom.timingFunction=CAMediaTimingFunction(controlPoints:0.25,0.1,0.5,1);zoom.fillMode = .forwards;zoom.isRemovedOnCompletion=false;canvas.layer?.add(zoom,forKey:"exitZoom")
 let fade=CABasicAnimation(keyPath:"opacity");fade.fromValue=1;fade.toValue=0;fade.duration=launching ? 0.18:0.22;fade.fillMode = .forwards;fade.isRemovedOnCompletion=false;canvas.layer?.add(fade,forKey:"exitFade")
 }
 func clearExitAnimation(){
 canvas.layer?.removeAnimation(forKey:"exitZoom");canvas.layer?.removeAnimation(forKey:"exitFade");launchGhost?.removeFromSuperview();launchGhost=nil;launchBusy=false
 for b in buttons {b.alphaValue=1}
 }
 func windowWillClose(_ notification:Notification){
 if let closing=notification.object as? NSWindow,closing === settings,window?.isVisible==true {window?.makeKeyAndOrderFront(nil);window?.makeFirstResponder(search)}
 }
 func presentSettings(_ panel:NSPanel){
 panel.level=NSWindow.Level(rawValue:(window?.level.rawValue ?? NSWindow.Level.floating.rawValue)+2)
 panel.delegate=self;panel.isFloatingPanel=true;panel.hidesOnDeactivate=false;panel.becomesKeyOnlyIfNeeded=false
 panel.collectionBehavior=[.canJoinAllSpaces,.fullScreenAuxiliary]
 if let window {
 if panel.parent !== window {panel.parent?.removeChildWindow(panel);window.addChildWindow(panel,ordered:.above)}
 let screen=window.screen ?? NSScreen.main
 if let rect=screen?.visibleFrame {panel.setFrameOrigin(NSPoint(x:rect.midX-panel.frame.width/2,y:rect.midY-panel.frame.height/2))}
 }
 NSApp.activate(ignoringOtherApps:true);panel.makeKeyAndOrderFront(nil);panel.orderFrontRegardless()
 }
 @objc func toggleFree(_ b:NSButton){store.layout.freeLayout=b.state == .on;if b.state == .on {store.layout.slots=nil;store.layout.syncSlots()} else {store.layout.slots=nil};store.save();page=0;endTileDrag();rebuild()}
 @objc func toggleFollow(_ b:NSButton){store.layout.followWallpaper=b.state == .on;store.save();if b.state == .on,let screen=window?.screen ?? NSScreen.main {refreshWallpaper(screen:screen)}}
 @objc func adjust(_ s:NSSlider){if s.tag==0 {store.layout.columns=s.integerValue} else if s.tag==1 {store.layout.rows=s.integerValue} else {store.layout.iconSize=s.doubleValue};page=0;store.save();rebuild(animated:false)}
 @objc func toggleBlur(_ b:NSButton){store.layout.blur=b.state == .on;store.save();if let screen=window?.screen ?? NSScreen.main {refreshWallpaper(screen:screen)};needsLayout=true}
 @objc func restoreHidden(){store.layout.hidden=[];store.scan();store.save();rebuild()}
 @objc func rescan(){store.scan();store.save();rebuild()}
}
struct PinchProgress {
 enum Phase {case began,changed,ended}
 let phase:Phase
 let direction:Int
 let progress:Double
}
struct ProgressivePinch {
 var ids:[Int32]=[];var origin:Double=0;var direction=0;var lastProgress:Double=0;var locked=false
 mutating func update(_ contacts:[(Int32,Double,Double)],time:Double)->PinchProgress? {
 if contacts.isEmpty {
 let event=direction==0 ? nil:PinchProgress(phase:.ended,direction:direction,progress:lastProgress)
 self=ProgressivePinch();return event
 }
 if contacts.count != 5 {
 if direction != 0 {let event=PinchProgress(phase:.ended,direction:direction,progress:lastProgress);direction=0;locked=true;return event}
 return nil
 }
 guard !locked else{return nil}
 let keys=contacts.map {$0.0}.sorted()
 let cx=contacts.map {$0.1}.reduce(0,+)/5,cy=contacts.map {$0.2}.reduce(0,+)/5
 let radius=sqrt(contacts.map {pow($0.1-cx,2)+pow($0.2-cy,2)}.reduce(0,+)/5)
 guard radius.isFinite,radius>0.015 else{return nil}
 if ids.isEmpty {ids=keys;origin=radius;return nil}
 if keys != ids {
 let event=direction==0 ? nil:PinchProgress(phase:.ended,direction:direction,progress:lastProgress)
 direction=0;locked=true;return event
 }
 let delta=radius-origin
 if direction==0 {
 guard abs(delta)>max(0.006,origin*0.025) else{return nil}
 direction=delta<0 ? -1:1
 let distance=max(origin*(direction<0 ? 0.24:0.30),0.045)
 lastProgress=min(1,max(0,abs(delta)/distance))
 return PinchProgress(phase:.began,direction:direction,progress:lastProgress)
 }
 let distance=max(origin*(direction<0 ? 0.24:0.30),0.045)
 let progress=min(1,max(0,delta*Double(direction)/distance))
 guard abs(progress-lastProgress)>=0.003 else{return nil}
 lastProgress=progress
 return PinchProgress(phase:.changed,direction:direction,progress:progress)
 }
}
struct RevealState {
 let startsOpen:Bool
 func amount(progress:Double)->Double {let p=min(1,max(0,progress));return startsOpen ? 1-p:p}
 func finishesOpen(progress:Double)->Bool {progress>=0.55 ? !startsOpen:startsOpen}
}

typealias TouchCallback = @convention(c) (UnsafeRawPointer?,UnsafeMutableRawPointer?,Int32,Double,Int32)->Int32
private weak var touchOwner:FiveFingerInput?
private let touchCallback:TouchCallback = {device,base,count,time,_ in
 guard let owner=touchOwner,let device else{return 0}
 var contacts:[(Int32,Double,Double)]=[]
 if let base,count>0,count<=16 {
 for i in 0..<Int(count) {
 let p=base.advanced(by:i*96)
 let state=p.load(fromByteOffset:20,as:Int32.self)
 if state==3 || state==4 {
 let x=Double(p.load(fromByteOffset:32,as:Float.self)),y=Double(p.load(fromByteOffset:36,as:Float.self))
 if x.isFinite,y.isFinite,x>=0,x<=1,y>=0,y<=1 {contacts.append((p.load(fromByteOffset:16,as:Int32.self),x,y))}
 }
 }
 }
 owner.frame(device:device,contacts:contacts,time:time)
 return 0
}
final class FiveFingerInput {
 typealias List = @convention(c) ()->Unmanaged<CFArray>?
 typealias Register = @convention(c) (UnsafeRawPointer,TouchCallback)->Void
 typealias Start = @convention(c) (UnsafeRawPointer,Int32)->Void
 typealias Stop = @convention(c) (UnsafeRawPointer)->Void
 var handle:UnsafeMutableRawPointer?;var devices:CFArray?;var pointers:[UnsafeRawPointer]=[]
 var unregister:Register?;var stopDevice:Stop?
 var detectors:[UInt:ProgressivePinch]=[:];var contactedDevices=Set<UInt>();let lock=NSLock()
 var contactBegan:(()->Void)?
 var gesture:((UInt,PinchProgress)->Void)?
 func start()->Int {
 stop()
 if handle==nil {handle=dlopen("/System/Library/PrivateFrameworks/MultitouchSupport.framework/MultitouchSupport",RTLD_NOW)}
 guard let h=handle,let ls=dlsym(h,"MTDeviceCreateList"),let rs=dlsym(h,"MTRegisterContactFrameCallback"),let ss=dlsym(h,"MTDeviceStart") else{return 0}
 let list=unsafeBitCast(ls,to:List.self),register=unsafeBitCast(rs,to:Register.self),start=unsafeBitCast(ss,to:Start.self)
 if let p=dlsym(h,"MTUnregisterContactFrameCallback") {unregister=unsafeBitCast(p,to:Register.self)}
 if let p=dlsym(h,"MTDeviceStop") {stopDevice=unsafeBitCast(p,to:Stop.self)}
 guard let array=list()?.takeRetainedValue() else{return 0}
 devices=array;touchOwner=self
 for i in 0..<CFArrayGetCount(array) {if let p=CFArrayGetValueAtIndex(array,i) {pointers.append(p);register(p,touchCallback);start(p,0)}}
 return pointers.count
 }
 func frame(device:UnsafeRawPointer,contacts:[(Int32,Double,Double)],time:Double) {
 lock.lock();let key=UInt(bitPattern:device)
 var began=false
 if contacts.isEmpty {contactedDevices.remove(key)}
 else if contacts.count>=2,!contactedDevices.contains(key) {contactedDevices.insert(key);began=true}
 var detector=detectors[key] ?? ProgressivePinch();let result=detector.update(contacts,time:time);detectors[key]=detector;lock.unlock()
 if began {DispatchQueue.main.async {[weak self] in self?.contactBegan?()}}
 if let result {DispatchQueue.main.async {[weak self] in self?.gesture?(key,result)}}
 }
 func stop(){for p in pointers {stopDevice?(p);unregister?(p,touchCallback)};pointers=[];devices=nil;lock.lock();detectors=[:];contactedDevices=[];lock.unlock()}
}

final class Delegate:NSObject,NSApplicationDelegate,NSMenuDelegate {
 var window:PadWindow!;var pad:PadView!;var monitor:Any?;var item:NSStatusItem!;let fingers=FiveFingerInput();var generation=0;var statusToggleItem:NSMenuItem?
 var previousApp:NSRunningApplication?;var wallpaperTimer:Timer?
 var handoff=LaunchHandoff();var pendingLaunchApp:NSRunningApplication?
 var revealState:RevealState?;var gestureDevice:UInt?;var gestureAmount:Double=1
 var gestureIgnored=false;var visualChecksRunning=false
 func applicationDidFinishLaunching(_ notification:Notification) {
 let mainMenu=NSMenu()
 let editItem=NSMenuItem(title:"编辑",action:nil,keyEquivalent:"");let editMenu=NSMenu(title:"编辑")
 for (title,action,key) in [("撤销","undo:","z"),("剪切","cut:","x"),("复制","copy:","c"),("粘贴","paste:","v"),("全选","selectAll:","a")] {editMenu.addItem(NSMenuItem(title:title,action:Selector(action),keyEquivalent:key))}
 editItem.submenu=editMenu;mainMenu.addItem(editItem);NSApp.mainMenu=mainMenu
 let screen=NSScreen.main
 window=PadWindow(contentRect:screen?.frame ?? NSRect(x:0,y:0,width:1200,height:800),styleMask:[.borderless],backing:.buffered,defer:false)
 window.title="启动台 · 0.8.2";window.isReleasedWhenClosed=false;window.isOpaque=false;window.backgroundColor = .clear;window.level = .floating
 window.acceptsMouseMovedEvents=true
 window.collectionBehavior = [.canJoinAllSpaces,.fullScreenAuxiliary,.ignoresCycle]
 let visualTest=Bundle.main.bundleIdentifier=="local.classiclaunchpad.visualtest"
 let library=Store(test:visualTest)
 if visualTest {
 let paths=["/System/Applications/Calendar.app","/System/Applications/Contacts.app","/System/Applications/Notes.app","/System/Applications/Calculator.app"]
 for path in paths {if let app=library.apps[path] {library.apps[path]=AppItem(path:path,name:app.name,icon:NSWorkspace.shared.icon(forFile:path))}}
 library.layout.tiles=[Tile(id:"demo-folder",name:"文件夹动画测试",paths:Array(paths.prefix(2)))]+paths.dropFirst(2).compactMap {library.apps[$0]}.map {Tile(name:$0.name,paths:[$0.path])}
 }
 pad=PadView(store:library);pad.launch={[weak self] path,origin in self?.launchApplication(path:path,origin:origin)};pad.dismiss={[weak self] in self?.hide()};window.escape={[weak self] in self?.pad.escape()};window.contentView=pad
 item=NSStatusBar.system.statusItem(withLength:NSStatusItem.variableLength)
 item.autosaveName="ClassicLaunchpadMenuBar";item.isVisible=true
 let statusImage=NSImage(systemSymbolName:"square.grid.3x3.fill",accessibilityDescription:"启动台")
 statusImage?.isTemplate=true;statusImage?.size=NSSize(width:16,height:16)
 item.button?.image=statusImage;item.button?.imagePosition = .imageLeading;item.button?.title="启动台"
 item.button?.font = .menuBarFont(ofSize:0);item.button?.setAccessibilityLabel("启动台菜单")
 let menu=NSMenu();menu.delegate=self
 let toggleItem=NSMenuItem(title:"打开启动台",action:#selector(toggle),keyEquivalent:"");toggleItem.target=self;statusToggleItem=toggleItem;menu.addItem(toggleItem)
 let settings=NSMenuItem(title:"设置…",action:#selector(openSettings),keyEquivalent:"");settings.target=self;menu.addItem(settings)
 menu.addItem(.separator())
 let quit=NSMenuItem(title:"退出启动台",action:#selector(terminate),keyEquivalent:"q");quit.target=self;menu.addItem(quit);item.menu=menu
 fingers.contactBegan = {[weak self] in self?.pad.pageSwipe.contactBegan()}
 fingers.gesture = {[weak self] device,event in self?.followPinch(event,device:device)}
 let count=visualTest ? 0:fingers.start();item.button?.toolTip=count>0 ? "0.8.2 · 五指收拢打开 / 收起；五指张开收起":"未检测到触控板；点击菜单显示启动台"
 monitor=NSEvent.addLocalMonitorForEvents(matching:.keyDown) {[weak self] event in
 if event.modifierFlags.contains(.command),(event.keyCode==43 || event.charactersIgnoringModifiers=="," || event.charactersIgnoringModifiers=="，") {self?.openSettings();return nil}
 if event.keyCode==53 {self?.pad.escape();return nil}
 if event.modifierFlags.contains(.command),event.charactersIgnoringModifiers=="q" {self?.terminate();return nil};return event
 }
 NSWorkspace.shared.notificationCenter.addObserver(self,selector:#selector(woke),name:NSWorkspace.didWakeNotification,object:nil)
 NSWorkspace.shared.notificationCenter.addObserver(self,selector:#selector(prepareForSleep),name:NSWorkspace.willSleepNotification,object:nil)
 NSWorkspace.shared.notificationCenter.addObserver(self,selector:#selector(desktopChanged),name:NSWorkspace.activeSpaceDidChangeNotification,object:nil)
 NotificationCenter.default.addObserver(self,selector:#selector(desktopChanged),name:NSApplication.didChangeScreenParametersNotification,object:nil)
 wallpaperTimer=Timer.scheduledTimer(withTimeInterval:2,repeats:true) {[weak self] _ in guard let self,self.window.isVisible,self.pad.store.layout.followWallpaper != false,let screen=self.window.screen else{return};self.pad.refreshWallpaper(screen:screen,force:false)}
 show()
 if visualTest {runGestureVisualChecks()}
 }
 @objc func prepareForSleep(){if gestureDevice != nil {generation+=1;cancelInteractivePinch();window.orderOut(nil)}}
 @objc func woke(){prepareForSleep();_ = fingers.start();desktopChanged()}
 @objc func desktopChanged(){guard pad.store.layout.followWallpaper != false,let screen=window.screen ?? NSScreen.main else{return};pad.refreshWallpaper(screen:screen)}
 func menuNeedsUpdate(_ menu:NSMenu){statusToggleItem?.title=window.isVisible ? "收起启动台":"打开启动台"}
 @objc func toggle(){if window.isVisible {hide()} else {show()}}
 func runGestureVisualChecks(){
 visualChecksRunning=true
 var checks:[String:Bool]=[:]
 func after(_ delay:Double,_ work:@escaping ()->Void){DispatchQueue.main.asyncAfter(deadline:.now()+delay,execute:work)}
 after(0.35){[self] in
 window.orderOut(nil)
 followPinch(PinchProgress(phase:.began,direction:-1,progress:0.25),device:999)
 checks["quarter_visible"]=abs(window.alphaValue-0.25)<0.001 && window.isVisible && window.ignoresMouseEvents
 after(0.15){[self] in
 followPinch(PinchProgress(phase:.changed,direction:-1,progress:0.50),device:999)
 checks["half_visible"]=abs(window.alphaValue-0.5)<0.001
 let scale=pad.canvas.layer?.transform.m11 ?? 0
 checks["half_scale"]=abs(scale-1.05)<0.001 || NSWorkspace.shared.accessibilityDisplayShouldReduceMotion
 followPinch(PinchProgress(phase:.changed,direction:-1,progress:0.20),device:999)
 checks["reversal"]=abs(window.alphaValue-0.2)<0.001
 followPinch(PinchProgress(phase:.ended,direction:-1,progress:0.20),device:999)
 after(0.5){[self] in
 checks["cancel_closed"] = !window.isVisible && !window.ignoresMouseEvents
 followPinch(PinchProgress(phase:.began,direction:-1,progress:0.20),device:999)
 followPinch(PinchProgress(phase:.changed,direction:-1,progress:0.80),device:999)
 checks["eighty_visible"]=abs(window.alphaValue-0.8)<0.001
 followPinch(PinchProgress(phase:.ended,direction:-1,progress:0.80),device:999)
 after(0.5){[self] in
 checks["commit_open"]=window.isVisible && abs(window.alphaValue-1)<0.001 && !window.ignoresMouseEvents
 followPinch(PinchProgress(phase:.began,direction:1,progress:0.30),device:999)
 checks["closing_seventy_visible"]=abs(window.alphaValue-0.7)<0.001
 followPinch(PinchProgress(phase:.ended,direction:1,progress:0.70),device:999)
 after(0.5){[self] in
 checks["commit_closed"] = !window.isVisible && !window.ignoresMouseEvents
 let destination=Bundle.main.bundleURL.deletingLastPathComponent().appendingPathComponent("gesture-ui-check.json")
 if let data=try? JSONSerialization.data(withJSONObject:checks,options:[.prettyPrinted,.sortedKeys]) {try? data.write(to:destination,options:.atomic)}
 visualChecksRunning=false;show()
 }
 }
 }
 }
 }
 }

 func followPinch(_ event:PinchProgress,device:UInt){
 switch event.phase {
 case .began:
 guard gestureDevice==nil else{return}
 gestureDevice=device
 // An outward gesture has no action while the launcher is closed.
 let open=window.isVisible && window.alphaValue>0.5
 gestureIgnored=pad.launchBusy || pad.draggedTileID != nil || pad.settings?.isVisible==true || (!open && event.direction>0)
 guard !gestureIgnored else{return}
 generation+=1;pendingLaunchApp=nil;pad.clearExitAnimation()
 revealState=RevealState(startsOpen:open)
 if !open {
 previousApp=NSWorkspace.shared.frontmostApplication
 let mouse=NSEvent.mouseLocation
 guard let screen=NSScreen.screens.first(where:{$0.frame.contains(mouse)}) ?? NSScreen.main else{cancelInteractivePinch();return}
 window.setFrame(screen.frame,display:false)
 if pad.store.layout.followWallpaper != false || pad.wallpaperKey.isEmpty {pad.refreshWallpaper(screen:screen,force:false)}
 pad.page=0;pad.folderID=nil;pad.search.stringValue="";pad.rebuild(animated:false)
 window.alphaValue=0;window.orderFrontRegardless()
 }
 pad.pageSwipe.reset();window.ignoresMouseEvents=true
 applyReveal(revealState!.amount(progress:event.progress))
 case .changed:
 guard gestureDevice==device,!gestureIgnored,let state=revealState else{return}
 applyReveal(state.amount(progress:event.progress))
 case .ended:
 guard gestureDevice==device else{return}
 if !gestureIgnored,let state=revealState {settleReveal(open:state.finishesOpen(progress:event.progress))}
 else if gestureIgnored {cancelInteractivePinch()}
 }
 }
 func applyReveal(_ amount:Double){
 let p=min(1,max(0,amount));gestureAmount=p
 CATransaction.begin();CATransaction.setDisableActions(true)
 window.alphaValue=p
 pad.canvas.wantsLayer=true
 let rect=pad.canvas.frame
 pad.canvas.layer?.anchorPoint=CGPoint(x:0.5,y:0.5);pad.canvas.layer?.position=CGPoint(x:rect.midX,y:rect.midY)
 let scale=NSWorkspace.shared.accessibilityDisplayShouldReduceMotion ? 1:1+(1-p)*0.10
 pad.canvas.layer?.transform=CATransform3DMakeScale(scale,scale,1)
 CATransaction.commit()
 }
 func settleReveal(open:Bool){
 let current=generation
 let target=open ? 1.0:0.0
 let start=gestureAmount
 let duration=0.10+abs(target-start)*0.16
 let oldTransform=pad.canvas.layer?.transform ?? CATransform3DIdentity
 CATransaction.begin();CATransaction.setDisableActions(true)
 pad.canvas.layer?.transform=open ? CATransform3DIdentity:CATransform3DMakeScale(1.10,1.10,1)
 CATransaction.commit()
 if !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion {
 let zoom=CABasicAnimation(keyPath:"transform");zoom.fromValue=NSValue(caTransform3D:oldTransform);zoom.toValue=NSValue(caTransform3D:pad.canvas.layer?.transform ?? CATransform3DIdentity);zoom.duration=duration;zoom.timingFunction=CAMediaTimingFunction(controlPoints:0.2,0.8,0.25,1);pad.canvas.layer?.add(zoom,forKey:"gestureSettle")
 }
 NSAnimationContext.runAnimationGroup({context in
 context.duration=duration;context.timingFunction=CAMediaTimingFunction(controlPoints:0.2,0.8,0.25,1);window.animator().alphaValue=target
 },completionHandler:{[weak self] in
 guard let self,self.generation==current else{return}
 self.cancelInteractivePinch();self.pad.canvas.layer?.transform=CATransform3DIdentity
 if open {self.window.alphaValue=1;self.window.makeKeyAndOrderFront(nil);self.window.makeFirstResponder(self.pad.search);NSApp.activate()}
 else {self.window.orderOut(nil);self.previousApp?.activate(options:[])}
 })
 // Retain the active device until settling completes, so a second device can't interrupt it.
 revealState=nil
 }
 func cancelInteractivePinch(){
 gestureDevice=nil;revealState=nil;gestureIgnored=false;window?.ignoresMouseEvents=false
 pad?.canvas.layer?.removeAnimation(forKey:"gestureSettle");pad?.canvas.layer?.transform=CATransform3DIdentity
 }
 func show(){
 cancelInteractivePinch();generation+=1;pad.clearExitAnimation();pendingLaunchApp=nil;previousApp=NSWorkspace.shared.frontmostApplication
 let mouse=NSEvent.mouseLocation
 guard let screen=NSScreen.screens.first(where:{$0.frame.contains(mouse)}) ?? NSScreen.main else{return}
 pad.pageSwipe.reset();window.setFrame(screen.frame,display:false);if pad.store.layout.followWallpaper != false || pad.wallpaperKey.isEmpty {pad.refreshWallpaper(screen:screen,force:false)};pad.page=0;pad.folderID=nil;pad.search.stringValue="";pad.rebuild(animated:false)
 window.alphaValue=0;window.makeKeyAndOrderFront(nil);window.makeFirstResponder(pad.search);NSApp.activate(ignoringOtherApps:true)
 NSAnimationContext.runAnimationGroup {context in context.duration=0.22;window.animator().alphaValue=1}
 pad.canvas.wantsLayer=true
 let zoom=CABasicAnimation(keyPath:"transform.scale");zoom.fromValue=1.08;zoom.toValue=1;zoom.duration=0.25;zoom.timingFunction=CAMediaTimingFunction(name:.easeOut);pad.canvas.layer?.add(zoom,forKey:"open")
 }
 func hide(restoreFocus:Bool=true,launching:Bool=false,onHidden:(()->Void)?=nil){
 guard window.isVisible else{onHidden?();return}
 cancelInteractivePinch();generation+=1;let current=generation;pad.endTileDrag();pad.pageSwipe.reset();pad.settings?.close()
 if !launching {pendingLaunchApp=nil;pad.launchBusy=false}
 pad.prepareExit(launching:launching)
 let reduced=NSWorkspace.shared.accessibilityDisplayShouldReduceMotion
 NSAnimationContext.runAnimationGroup({context in
 context.duration=reduced ? 0.12:(launching ? 0.29:0.23)
 context.timingFunction=CAMediaTimingFunction(controlPoints:0.25,0.1,0.5,1)
 window.animator().alphaValue=0
 },completionHandler:{[weak self] in
 guard let self,self.generation==current else{return}
 self.window.orderOut(nil);self.pad.clearExitAnimation()
 if restoreFocus {self.previousApp?.activate(options:[])}
 onHidden?()
 })
 }
 func launchApplication(path:String,origin:NSRect){
 guard !pad.launchBusy else{return}
 handoff=LaunchHandoff();pendingLaunchApp=nil
 if let identifier=Bundle(url:URL(fileURLWithPath:path))?.bundleIdentifier {NSApp.yieldActivation(toApplicationWithBundleIdentifier:identifier)}
 pad.prepareLaunch(path:path,origin:origin)
 hide(restoreFocus:false,launching:true) {[weak self] in
 guard let self else{return}
 if self.handoff.hidden() {self.activateLaunchedApplication()}
 }
 let token=generation
 let config=NSWorkspace.OpenConfiguration();config.activates=false
 NSWorkspace.shared.openApplication(at:URL(fileURLWithPath:path),configuration:config) {[weak self] application,error in
 DispatchQueue.main.async {
 guard let self,self.generation==token else{return}
 if let application {
 self.pendingLaunchApp=application
 if self.handoff.ready() {self.activateLaunchedApplication()}
 } else if let error {
 self.show()
 let alert=NSAlert();alert.messageText="无法打开应用";alert.informativeText=error.localizedDescription;alert.addButton(withTitle:"好");alert.beginSheetModal(for:self.window)
 }
 }
 }
 }
 func activateLaunchedApplication(){
 guard let app=pendingLaunchApp else{return}
 pendingLaunchApp=nil
 NSApp.yieldActivation(to:app)
 app.activate(from:.current,options:[])
 }
 @objc func openSettings(){if !window.isVisible {show()};pad.showSettings()}
 @objc func terminate(){cancelInteractivePinch();window.orderOut(nil);fingers.stop();NSApp.terminate(nil)}
 func applicationWillTerminate(_ notification:Notification){fingers.stop()}
 func applicationShouldHandleReopen(_ sender:NSApplication,hasVisibleWindows flag:Bool)->Bool {if visualChecksRunning {return false};if window.isVisible && window.alphaValue>0.98 {window.makeKeyAndOrderFront(nil);NSApp.activate()} else {show()};return false}
 func applicationShouldTerminateAfterLastWindowClosed(_ sender:NSApplication)->Bool {false}
}
if CommandLine.arguments.contains("--self-test") {
 let store=Store(test:true)
 precondition(!store.apps.isEmpty,"No applications found")
 precondition(store.layout.tiles.allSatisfy {!$0.paths.isEmpty})
 if let first=store.apps.values.first {precondition(!store.results(first.name).isEmpty)}
 let layout=try JSONDecoder().decode(Layout.self,from:JSONEncoder().encode(store.layout));precondition(layout.tiles.count==store.layout.tiles.count)
 precondition(store.results("not-a-real-app-094831").isEmpty)
 var swipe=PageSwipe()
 func event(_ x:Double,_ time:Double,begin:Bool=false,end:Bool=false,momentum:Bool=false,y:Double=0)->Int? {
 swipe.feed(x:x,y:y,precise:true,begin:begin,end:end,cancel:false,momentum:momentum,phased:true,time:time)
 }
 precondition(event(-25,1,begin:true)==nil)
 precondition(event(-25,1.1)==1)
 precondition(event(-100,1.7)==nil) // long gesture must not skip another page
 precondition(event(-20,1.8,end:true)==nil)
 precondition(event(-200,2.3,momentum:true)==nil)
 precondition(event(-200,2.9,momentum:true)==nil)
 precondition(event(25,3,begin:true)==nil)
 precondition(event(25,3.1)==(-1))
 precondition(event(100,3.7,end:true)==nil)
 precondition(event(-100,4,begin:true,y:200)==nil) // vertical scroll ignored
 swipe.reset()
 precondition(event(-15,5,begin:true)==nil)
 precondition(event(-15,5.1,end:true)==nil) // small swipe does not leak into next
 precondition(event(-15,6,begin:true)==nil)
 precondition(event(-15,6.1,end:true)==nil)
 var wheel=PageSwipe()
 precondition(wheel.feed(x:0,y:-3,precise:false,begin:false,end:false,cancel:false,momentum:false,phased:false,time:1)==1)
 precondition(wheel.feed(x:0,y:-3,precise:false,begin:false,end:false,cancel:false,momentum:false,phased:false,time:1.1)==nil)
 precondition(wheel.feed(x:0,y:-3,precise:false,begin:false,end:false,cancel:false,momentum:false,phased:false,time:2)==1)
 var physical=PageSwipe()
 physical.contactBegan()
 precondition(physical.feed(x:-45,y:0,precise:true,begin:true,end:false,cancel:false,momentum:false,phased:true,time:1)==1)
 // A spurious second begin while the same fingers remain down must not rearm.
 precondition(physical.feed(x:-80,y:0,precise:true,begin:true,end:false,cancel:false,momentum:false,phased:true,time:2)==nil)
 precondition(physical.feed(x:0,y:0,precise:true,begin:false,end:true,cancel:false,momentum:false,phased:true,time:2.1)==nil)
 precondition(physical.feed(x:-80,y:0,precise:true,begin:false,end:false,cancel:false,momentum:false,phased:true,time:3)==nil)
 precondition(physical.feed(x:-80,y:0,precise:true,begin:false,end:false,cancel:false,momentum:true,phased:false,time:4)==nil)
 physical.contactBegan()
 precondition(physical.feed(x:-45,y:0,precise:true,begin:true,end:false,cancel:false,momentum:false,phased:true,time:5)==1)
 print("PASS: hardware contact latch rejects duplicate began events, late changed events and unphased tails")
 var arrangement=Layout()
 let a=Tile(id:"a",name:"A",paths:["a"]),b=Tile(id:"b",name:"B",paths:["b"]),c=Tile(id:"c",name:"C",paths:["c"])
 arrangement.tiles=[a,b,c]
 arrangement.place(c,from:nil,target:"a",group:false,index:0)
 precondition(arrangement.tiles.map(\.id)==["c","a","b"])
 arrangement.place(a,from:nil,target:"b",group:true,index:0)
 precondition(arrangement.tiles.map(\.id)==["c","b"])
 precondition(arrangement.tiles[1].paths==["b","a"])
 arrangement.reorderInFolder("b",path:"a",before:"b")
 precondition(arrangement.tiles[1].paths==["a","b"])
 arrangement.place(a,from:"b",target:nil,group:false,index:2)
 precondition(arrangement.tiles.map(\.id)==["c","b","a"])
 precondition(arrangement.tiles.flatMap(\.paths).sorted()==["a","b","c"])
 arrangement.place(a,from:nil,target:"a",group:true,index:0)
 precondition(arrangement.tiles.flatMap(\.paths).sorted()==["a","b","c"])
 let roundTrip=try JSONDecoder().decode(Layout.self,from:JSONEncoder().encode(arrangement))
 precondition(roundTrip.tiles.map(\.id)==arrangement.tiles.map(\.id))
 precondition(roundTrip.tiles.flatMap(\.paths)==arrangement.tiles.flatMap(\.paths))
 print("PASS: one page per swipe, momentum rejection, vertical scroll rejection, mouse-wheel bursts")
 print("PASS: reorder, folder creation, folder reorder, extraction, membership preservation, persistence")
 var free=Layout();free.tiles=[a,b,c];free.freeLayout=true;free.syncSlots()
 free.moveFree(a,from:nil,to:18,group:nil)
 precondition(free.slots?["a"]==18 && free.slots?["b"]==1 && free.slots?["c"]==2)
 free.moveFree(a,from:nil,to:1,group:nil)
 precondition(free.slots?["a"]==1 && free.slots?["b"]==18)
 free.moveFree(a,from:nil,to:2,group:"c")
 precondition(free.slots?["b"]==18 && free.slots?["c"]==2 && free.slots?["a"]==nil)
 free.moveFree(a,from:"c",to:50,group:nil)
 precondition(free.slots?["a"]==50 && free.slots?["c"]==2)
 let freeRestored=try JSONDecoder().decode(Layout.self,from:JSONEncoder().encode(free))
 precondition(freeRestored.slots==free.slots)
 let legacy=Data("{\"tiles\":[],\"hidden\":[],\"columns\":7,\"rows\":5,\"iconSize\":76,\"blur\":true}".utf8)
 let legacyLayout=try JSONDecoder().decode(Layout.self,from:legacy)
 precondition(legacyLayout.freeLayout==nil && legacyLayout.followWallpaper==nil)
 let calendarURL=URL(fileURLWithPath:"/System/Applications/Calendar.app")
 precondition(chineseAppName(url:calendarURL,bundle:Bundle(url:calendarURL))=="日历")
 let activityURL=URL(fileURLWithPath:"/System/Applications/Utilities/Activity Monitor.app")
 precondition(chineseAppName(url:activityURL,bundle:Bundle(url:activityURL))=="活动监视器")
 precondition(store.results("日历").count>=1 && store.results("Calendar").count>=1)
 print("PASS: Chinese system app names and bilingual search")
 print("PASS: free layout gaps, occupied-slot exchange, folder placement, sparse persistence and legacy settings migration")
 var edge=DragPageEdge()
 precondition(edge.update(x:1190,y:400,width:1200,height:800,time:1)==nil)
 precondition(edge.update(x:1190,y:400,width:1200,height:800,time:1.3)==nil)
 precondition(edge.update(x:1200,y:400,width:1200,height:800,time:1.5)==1)
 precondition(edge.update(x:1200,y:400,width:1200,height:800,time:4)==nil)
 precondition(edge.update(x:600,y:400,width:1200,height:800,time:5)==nil)
 precondition(edge.update(x:1190,y:400,width:1200,height:800,time:6)==nil)
 precondition(edge.update(x:1190,y:400,width:1200,height:800,time:6.5)==1)
 precondition(edge.update(x:10,y:400,width:1200,height:800,time:7)==nil)
 precondition(edge.update(x:0,y:400,width:1200,height:800,time:7.5)==(-1))
 precondition(edge.update(x:0,y:900,width:1200,height:800,time:8)==nil)
 precondition(edge.update(x:1300,y:400,width:1200,height:800,time:9)==nil)
 var pages=Layout();pages.tiles=(0..<80).map {Tile(id:String($0),name:String($0),paths:[String($0)])}
 let moved=pages.tiles[0]
 pages.place(moved,from:nil,target:"42",group:false,index:70)
 precondition(pages.tiles[41].id=="0" && pages.tiles[42].id=="42")
 precondition(Set(pages.tiles.flatMap(\.paths)).count==80)
 print("PASS: drag edge dwell, exact screen boundary, one turn per edge visit, rearm, both directions and cross-page placement")
 var fastLaunch=LaunchHandoff()
 precondition(!fastLaunch.ready())
 precondition(fastLaunch.hidden())
 precondition(!fastLaunch.hidden() && !fastLaunch.ready())
 var coldLaunch=LaunchHandoff()
 precondition(!coldLaunch.hidden())
 precondition(coldLaunch.ready())
 precondition(!coldLaunch.ready() && !coldLaunch.hidden())
 print("PASS: fast and cold app launches activate exactly once after the overlay is hidden")
 let fakeChoice:[String:Any] = ["Linked":["Content":["Choices":[["Provider":"com.apple.wallpaper.choice.aerials","Configuration":try PropertyListSerialization.data(fromPropertyList:["assetID":"test"],format:.binary,options:0)]]]]]
 let node=SystemWallpaper.selectedNode(["AllSpacesAndDisplays":"$null","Displays":["screen-a":fakeChoice],"SystemDefault":["Desktop":["Content":["Choices":[]]]]],display:"screen-a",space:nil)
 precondition(SystemWallpaper.choice(in:node ?? [:])?.assetID=="test")
 let perSpace=SystemWallpaper.selectedNode(["Spaces":["space-a":["Displays":["screen-a":fakeChoice]]]],display:"screen-a",space:"space-a")
 precondition(SystemWallpaper.choice(in:perSpace ?? [:])?.provider=="com.apple.wallpaper.choice.aerials")
 let malformed:[String:Any] = ["Desktop":["Content":["Choices":[["Provider":"third.party","Configuration":Data("display-1".utf8)]]]]]
 precondition(SystemWallpaper.choice(in:malformed)?.provider=="third.party")
 precondition(SystemWallpaper.choice(in:["Idle":fakeChoice])==nil)
 let cacheA=WallpaperCacheCandidate(url:URL(fileURLWithPath:"/a.bmp"),width:2560,height:1440,modified:Date(timeIntervalSince1970:1))
 let cacheB=WallpaperCacheCandidate(url:URL(fileURLWithPath:"/b.bmp"),width:3420,height:2214,modified:Date(timeIntervalSince1970:3))
 let cacheC=WallpaperCacheCandidate(url:URL(fileURLWithPath:"/c.bmp"),width:2560,height:1440,modified:Date(timeIntervalSince1970:2))
 precondition(SystemWallpaper.bestCache([cacheA,cacheB,cacheC],width:2560,height:1440)?.url==cacheC.url)
 precondition(SystemWallpaper.bestCache([cacheA,cacheB,cacheC],width:3420,height:2214)?.url==cacheB.url)
 precondition(SystemWallpaper.bestCache([cacheA],width:1920,height:1080)==nil)
 if let real=SystemWallpaper.shared.file(display:nil,space:nil,width:2560,height:1440,legacy:nil) {print("LOCAL WALLPAPER:",real.kind,real.url.lastPathComponent);precondition(FileManager.default.fileExists(atPath:real.url.path))}
 print("PASS: current wallpaper provider, per-display/Space selection, malformed provider handling and exact-display cache matching")
 func contacts(_ radius:Double,shift:Double=0)->[(Int32,Double,Double)] {(0..<5).map {i in let angle=Double(i)*2*Double.pi/5;return (Int32(i),0.5+shift+cos(angle)*radius,0.5+sin(angle)*radius)}}
 var detector=ProgressivePinch()
 precondition(detector.update(contacts(0.3),time:1)==nil)
 let early=detector.update(contacts(0.285),time:1.1)!
 precondition(early.phase == .began && early.direction == -1 && early.progress>0 && early.progress<0.3)
 let halfway=detector.update(contacts(0.264),time:1.2)!
 precondition(halfway.phase == .changed && abs(halfway.progress-0.5)<0.001)
 let reverse=detector.update(contacts(0.282),time:1.3)!
 precondition(reverse.progress<halfway.progress)
 let cancelled=detector.update([],time:1.4)!
 precondition(cancelled.phase == .ended && cancelled.progress<0.55)
 precondition(detector.update(contacts(0.3),time:2)==nil)
 precondition(detector.update(contacts(0.2),time:2.1)!.progress==1)
 precondition(detector.update(Array(contacts(0.2).prefix(4)),time:2.2)!.phase == .ended)
 precondition(detector.update(contacts(0.18),time:2.3)==nil) // no repeat before all fingers lift
 _ = detector.update([],time:2.4)
 precondition(detector.update(contacts(0.15),time:3)==nil)
 precondition(detector.update(contacts(0.18),time:3.1)!.direction==1)
 precondition(detector.update(contacts(0.21),time:3.2)!.progress==1)
 _ = detector.update([],time:3.3)
 precondition(detector.update(Array(contacts(0.3).prefix(4)),time:4)==nil)
 _ = detector.update([],time:4.1)
 precondition(detector.update(contacts(0.3),time:5)==nil)
 precondition(detector.update(contacts(0.3,shift:0.1),time:5.1)==nil) // translation doesn't reveal
 let opening=RevealState(startsOpen:false),closing=RevealState(startsOpen:true)
 precondition(opening.amount(progress:0.25)==0.25 && closing.amount(progress:0.25)==0.75)
 precondition(!opening.finishesOpen(progress:0.3) && opening.finishesOpen(progress:0.8))
 precondition(closing.finishesOpen(progress:0.3) && !closing.finishesOpen(progress:0.8))
 print("PASS: continuous five-finger progress, reversal, release cancellation, completion, outward close and no repeat")
 print("PASS: scanned \(store.apps.count) apps; search, layout serialization, and nonempty tiles verified")
} else {
 let app=NSApplication.shared;let delegate=Delegate();app.delegate=delegate;app.setActivationPolicy(.regular);withExtendedLifetime(delegate) {app.run()}
}
